// config.js
module.exports = {
    panel: {
        domain: 'https://', //domain lu bang🗿
        appKey: 'ptla_', // key ptla lu
        clientKey: 'ptlc_' // key ptlc lu
    },
    
    owner: ["6282261226120"],
    ownername: "Kenz crt",
    botname: "Kenz Ai",
    botver: "2.0.0",
    idch: "120363419666720399@newsletter",
    newsletterName: "Nugget",
    packname: "uget",
    author: "ribka punya uget",
    
    mess: {
        success: '𝙳𝚘𝚗𝚎 ga bang? done',
        admin: '_*❗Perintah Ini Hanya Bisa Digunakan Oleh Admin Group !*_',
        botAdmin: '_*❗Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !*_',
        OnlyOwner: '_*❗Perintah Ini Hanya Bisa Digunakan Oleh Owner !*_',
        OnlyGrup: '_*❗Perintah Ini Hanya Bisa Digunakan Di Group Chat !*_',
        private: '_(❗Perintah Ini Hanya Bisa Digunakan Di Private Chat !*_',
        wait: '_*Wait Tunggu Sebentar*_',
        owner: '_*apelah khusus kenz jir*_',
        premium: '_*Khusus Premium" Mau Prem? Chat kenz bang*_'
    }
}

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(`Update ${__filename}`)
    delete require.cache[file]
    require(file)
})